# Deploy JAMB Mock Pro to Netlify (Free)

## Quick Deployment Steps

### Option 1: Direct from Replit (Recommended)
1. **Export your project:**
   - Download your entire project as a ZIP file from Replit
   - Extract the ZIP file on your computer

2. **Prepare for Netlify:**
   - Your `client` folder contains the frontend React app
   - Run `npm run build` to create the `client/dist` folder
   - The `client/dist` folder is what you'll deploy to Netlify

3. **Deploy to Netlify:**
   - Go to [netlify.com](https://netlify.com) and sign up for free
   - Click "Deploy to Netlify" > "Browse to upload"
   - Upload the `client/dist` folder (after running build)
   - Your app will get a URL like `amazing-app-name.netlify.app`

### Option 2: Git Integration (Better for updates)
1. **Push to GitHub:**
   - Create a new GitHub repository
   - Push your Replit project to GitHub

2. **Connect Netlify to GitHub:**
   - In Netlify, click "New site from Git"
   - Connect your GitHub repository
   - Set build settings:
     - Build command: `npm run build`
     - Publish directory: `client/dist`

## Important Notes

### Frontend-Only Deployment
Since Netlify is for static sites, your app will run in **frontend-only mode**:
- Authentication with Google will work
- Practice mode will work with local storage
- Payment system will need to be adapted or use external services
- Exam data will be stored locally in the browser

### Environment Variables
Add these in Netlify dashboard under "Site settings" > "Environment variables":
```
VITE_GA_MEASUREMENT_ID=your-google-analytics-id
VITE_HCAPTCHA_SITE_KEY=your-hcaptcha-site-key
```

### Custom Domain for hCaptcha
Once deployed, you'll get a clean domain like:
`jamb-mock-pro.netlify.app`

Use this domain in your hCaptcha dashboard settings.

## Alternative: Frontend + Backend on Different Services
- Frontend: Netlify (free)
- Backend API: Railway, Render, or Heroku (free tiers available)
- Database: Neon, PlanetScale, or Supabase (free tiers)