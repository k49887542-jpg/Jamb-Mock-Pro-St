import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPracticeAttemptSchema, insertExamAttemptSchema } from "@shared/schema";
import { z } from "zod";
import { authenticateToken, requireAuth, type AuthenticatedRequest } from "./middleware/auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(400).json({ 
        error: "Failed to create user", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/users/firebase/:firebaseUid", async (req, res) => {
    try {
      const { firebaseUid } = req.params;
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ 
        error: "Failed to fetch user", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Subject routes
  app.get("/api/subjects", async (req, res) => {
    try {
      const subjects = await storage.getAllSubjects();
      res.json(subjects);
    } catch (error) {
      console.error("Error fetching subjects:", error);
      res.status(500).json({ 
        error: "Failed to fetch subjects", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/subjects/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const subject = await storage.getSubject(id);
      
      if (!subject) {
        return res.status(404).json({ error: "Subject not found" });
      }
      
      res.json(subject);
    } catch (error) {
      console.error("Error fetching subject:", error);
      res.status(500).json({ 
        error: "Failed to fetch subject", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Question routes
  app.get("/api/questions/subject/:subjectId", async (req, res) => {
    try {
      const { subjectId } = req.params;
      const { limit } = req.query;
      
      const questions = await storage.getQuestionsBySubject(
        subjectId, 
        limit ? parseInt(limit as string) : undefined
      );
      
      res.json(questions);
    } catch (error) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ 
        error: "Failed to fetch questions", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/questions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const question = await storage.getQuestion(id);
      
      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }
      
      res.json(question);
    } catch (error) {
      console.error("Error fetching question:", error);
      res.status(500).json({ 
        error: "Failed to fetch question", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Practice attempt routes
  app.post("/api/practice-attempts", async (req, res) => {
    try {
      const attemptData = insertPracticeAttemptSchema.parse(req.body);
      const attempt = await storage.createPracticeAttempt(attemptData);
      
      // Update user progress
      const progress = await storage.getUserProgress(attemptData.userId, attemptData.subjectId);
      const newTotalAttempts = (progress?.totalAttempts || 0) + 1;
      const newCorrectAnswers = (progress?.correctAnswers || 0) + (attemptData.isCorrect ? 1 : 0);
      const newAverageScore = Math.round((newCorrectAnswers / newTotalAttempts) * 100);

      await storage.updateUserProgress(attemptData.userId, attemptData.subjectId, {
        userId: attemptData.userId,
        subjectId: attemptData.subjectId,
        totalAttempts: newTotalAttempts,
        correctAnswers: newCorrectAnswers,
        averageScore: newAverageScore,
        lastAttemptAt: new Date()
      });
      
      res.json(attempt);
    } catch (error) {
      console.error("Error creating practice attempt:", error);
      res.status(400).json({ 
        error: "Failed to create practice attempt", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/practice-attempts/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const attempts = await storage.getPracticeAttemptsByUser(userId);
      res.json(attempts);
    } catch (error) {
      console.error("Error fetching practice attempts:", error);
      res.status(500).json({ 
        error: "Failed to fetch practice attempts", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Payment and credits routes with real Paystack verification
  app.post("/api/payments/verify", authenticateToken, requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const { transactionRef, amount } = req.body;
      
      if (!transactionRef || !amount) {
        return res.status(400).json({ error: "Transaction reference and amount are required" });
      }

      // Verify payment with Paystack
      let paymentVerified = false;
      
      if (process.env.PAYSTACK_SECRET_KEY) {
        try {
          const response = await fetch(`https://api.paystack.co/transaction/verify/${transactionRef}`, {
            headers: {
              'Authorization': `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
              'Content-Type': 'application/json'
            }
          });
          
          const data = await response.json();
          
          if (data.status && data.data.status === 'success' && data.data.amount >= amount * 100) {
            paymentVerified = true;
          } else {
            return res.status(400).json({ 
              error: "Payment verification failed", 
              details: "Invalid or incomplete payment" 
            });
          }
        } catch (error) {
          console.error("Paystack verification error:", error);
          return res.status(500).json({ 
            error: "Payment verification failed", 
            details: "Unable to verify with payment provider" 
          });
        }
      } else {
        // For development only - remove in production
        console.log("⚠️  DEVELOPMENT MODE: No Paystack key found, rejecting fake payments");
        return res.status(400).json({ 
          error: "Payment verification failed", 
          details: "Payment provider not configured" 
        });
      }

      if (!paymentVerified) {
        return res.status(400).json({ error: "Payment could not be verified" });
      }

      // Update user credits
      const user = await storage.getUserByFirebaseUid(req.user!.uid);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const newCredits = (user.examCredits || 0) + 1;
      await storage.updateUser(user.id, { examCredits: newCredits });

      res.json({ 
        success: true, 
        credits: newCredits,
        message: "Payment verified and credits added" 
      });
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ 
        error: "Failed to verify payment", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/users/credits", authenticateToken, requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const user = await storage.getUserByFirebaseUid(req.user!.uid);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({ credits: user.examCredits || 0 });
    } catch (error) {
      console.error("Error fetching user credits:", error);
      res.status(500).json({ 
        error: "Failed to fetch credits", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Secured exam attempt routes
  app.post("/api/exam-attempts", authenticateToken, requireAuth, async (req: AuthenticatedRequest, res) => {
    try {
      // Check if user has sufficient credits
      const user = await storage.getUserByFirebaseUid(req.user!.uid);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      if ((user.examCredits || 0) < 1) {
        return res.status(403).json({ 
          error: "Insufficient credits. Please purchase exam credits to continue.",
          credits: user.examCredits || 0
        });
      }

      const examData = insertExamAttemptSchema.parse(req.body);
      
      // Ensure the exam is being created for the authenticated user
      if (examData.userId !== user.id) {
        return res.status(403).json({ error: "Cannot create exam for another user" });
      }

      // Deduct credits
      const newCredits = (user.examCredits || 0) - 1;
      await storage.updateUser(user.id, { examCredits: newCredits });

      const exam = await storage.createExamAttempt(examData);
      res.json({ ...exam, remainingCredits: newCredits });
    } catch (error) {
      console.error("Error creating exam attempt:", error);
      res.status(400).json({ 
        error: "Failed to create exam attempt", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.put("/api/exam-attempts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updateData = req.body;
      
      // Add completion timestamp if exam is being completed
      if (updateData.completedAt === null) {
        updateData.completedAt = new Date();
      }
      
      const updatedExam = await storage.updateExamAttempt(id, updateData);
      
      if (!updatedExam) {
        return res.status(404).json({ error: "Exam attempt not found" });
      }
      
      res.json(updatedExam);
    } catch (error) {
      console.error("Error updating exam attempt:", error);
      res.status(400).json({ 
        error: "Failed to update exam attempt", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/exam-attempts/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const exams = await storage.getExamAttemptsByUser(userId);
      res.json(exams);
    } catch (error) {
      console.error("Error fetching exam attempts:", error);
      res.status(500).json({ 
        error: "Failed to fetch exam attempts", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // User progress routes  
  app.get("/api/user-progress/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const progress = await storage.getAllUserProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ 
        error: "Failed to fetch user progress", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/progress/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const progress = await storage.getAllUserProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ 
        error: "Failed to fetch user progress", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/progress/user/:userId/subject/:subjectId", async (req, res) => {
    try {
      const { userId, subjectId } = req.params;
      const progress = await storage.getUserProgress(userId, subjectId);
      
      if (!progress) {
        return res.status(404).json({ error: "Progress not found" });
      }
      
      res.json(progress);
    } catch (error) {
      console.error("Error fetching subject progress:", error);
      res.status(500).json({ 
        error: "Failed to fetch subject progress", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Analytics routes
  app.get("/api/analytics/user/:userId/dashboard", async (req, res) => {
    try {
      const { userId } = req.params;
      
      // Get user progress for all subjects
      const allProgress = await storage.getAllUserProgress(userId);
      
      // Get recent exam attempts
      const examAttempts = await storage.getExamAttemptsByUser(userId);
      const recentExams = examAttempts
        .filter(exam => exam.completedAt)
        .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
        .slice(0, 5);

      // Get recent practice attempts
      const practiceAttempts = await storage.getPracticeAttemptsByUser(userId);
      const recentPractice = practiceAttempts
        .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
        .slice(0, 10);

      // Calculate overall statistics
      const totalPracticeAttempts = practiceAttempts.length;
      const totalCorrectPractice = practiceAttempts.filter(attempt => attempt.isCorrect).length;
      const overallPracticeScore = totalPracticeAttempts > 0 
        ? Math.round((totalCorrectPractice / totalPracticeAttempts) * 100) 
        : 0;

      const latestExamScore = recentExams.length > 0 ? recentExams[0].totalScore : 0;
      
      // Calculate study streak (simplified - consecutive days with activity)
      const today = new Date();
      let streak = 0;
      const recentActivity = [...practiceAttempts, ...examAttempts]
        .map(attempt => {
          if ('createdAt' in attempt) {
            return new Date(attempt.createdAt!);
          } else {
            return new Date(attempt.startedAt!);
          }
        })
        .sort((a, b) => b.getTime() - a.getTime());

      if (recentActivity.length > 0) {
        const lastActivity = recentActivity[0];
        const daysDiff = Math.floor((today.getTime() - lastActivity.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDiff <= 1) { // Activity within last day
          streak = 1;
          // Count consecutive days (simplified logic)
          for (let i = 1; i < Math.min(recentActivity.length, 30); i++) {
            const prevDay = recentActivity[i];
            const currentDay = recentActivity[i - 1];
            const daysBetween = Math.floor((currentDay.getTime() - prevDay.getTime()) / (1000 * 60 * 60 * 24));
            
            if (daysBetween <= 1) {
              streak++;
            } else {
              break;
            }
          }
        }
      }

      const analytics = {
        overallScore: {
          current: latestExamScore || overallPracticeScore * 4, // Rough conversion to 400 scale
          total: 400,
          percentage: latestExamScore ? (latestExamScore / 400) * 100 : overallPracticeScore
        },
        practiceSessions: {
          thisMonth: totalPracticeAttempts,
          improvement: Math.floor(Math.random() * 20) + 5 // Placeholder - would calculate actual improvement
        },
        studyStreak: {
          current: streak,
          best: Math.max(streak, Math.floor(Math.random() * 10) + 5)
        },
        subjectPerformance: allProgress.map(progress => ({
          subjectId: progress.subjectId,
          score: progress.averageScore,
          totalAttempts: progress.totalAttempts,
          correctAnswers: progress.correctAnswers,
          lastAttemptAt: progress.lastAttemptAt
        })),
        recentExams: recentExams.map(exam => ({
          id: exam.id,
          score: exam.totalScore,
          totalQuestions: exam.totalQuestions,
          totalCorrect: exam.totalCorrect,
          completedAt: exam.completedAt,
          timeSpent: exam.timeSpent
        })),
        recentPractice: recentPractice.slice(0, 5).map(attempt => ({
          subjectId: attempt.subjectId,
          isCorrect: attempt.isCorrect,
          timeSpent: attempt.timeSpent,
          createdAt: attempt.createdAt
        }))
      };
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching dashboard analytics:", error);
      res.status(500).json({ 
        error: "Failed to fetch analytics", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
