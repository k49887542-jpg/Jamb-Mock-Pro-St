import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCJLHX7TNrgb3ZJGhU7ilMTP-4TY0I3nQU",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "jamb-mock-pro.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "jamb-mock-pro",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "jamb-mock-pro.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "377236731071",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:377236731071:web:9a52738d793a5abad8020a",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-XTK34JLZN4"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const analytics = getAnalytics(app);
export default app;
