import { analytics } from './firebase';
import { logEvent, setUserId, setUserProperties } from 'firebase/analytics';

// Define the gtag function globally for backward compatibility
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Initialize Google Analytics with Firebase Analytics
export const initGA = () => {
  const measurementId = import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-XTK34JLZN4";

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_FIREBASE_MEASUREMENT_ID');
    return;
  }

  // Add Google Analytics script to the head for gtag compatibility
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  // Initialize gtag
  const script2 = document.createElement('script');
  script2.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}');
  `;
  document.head.appendChild(script2);
};

// Track page views - useful for single-page applications
export const trackPageView = (url: string) => {
  // Firebase Analytics
  if (analytics) {
    logEvent(analytics, 'page_view', {
      page_location: url,
      page_title: document.title
    });
  }
  
  // Backward compatibility with gtag
  if (typeof window !== 'undefined' && window.gtag) {
    const measurementId = import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-XTK34JLZN4";
    window.gtag('config', measurementId, {
      page_path: url
    });
  }
};

// Track events with Firebase Analytics
export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  // Firebase Analytics
  if (analytics) {
    logEvent(analytics, action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
  
  // Backward compatibility with gtag
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: label,
      value: value,
    });
  }
};

// Track user properties for Firebase Analytics
export const trackUser = (userId: string, properties?: Record<string, any>) => {
  if (analytics) {
    setUserId(analytics, userId);
    if (properties) {
      setUserProperties(analytics, properties);
    }
  }
};