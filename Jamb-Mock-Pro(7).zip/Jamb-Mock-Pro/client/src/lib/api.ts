import { auth } from './firebase';

// Helper function to get auth token for API requests
export async function getAuthToken(): Promise<string | null> {
  const user = auth.currentUser;
  if (!user) return null;
  
  try {
    return await user.getIdToken();
  } catch (error) {
    console.error('Error getting auth token:', error);
    return null;
  }
}

// Helper function to make authenticated API requests
export async function apiRequest<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = await getAuthToken();
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
    throw new Error(errorData.error || `HTTP ${response.status}`);
  }

  return response.json();
}

// User API functions
export const userApi = {
  getCurrentUser: async () => {
    const user = auth.currentUser;
    if (!user) throw new Error('No authenticated user');
    
    return apiRequest<any>(`/api/users/firebase/${user.uid}`);
  },

  createUser: async (userData: any) => {
    return apiRequest<any>('/api/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },

  getUserCredits: async () => {
    return apiRequest<{ credits: number }>('/api/users/credits');
  },
};

// Payment API functions
export const paymentApi = {
  verifyPayment: async (transactionReference: string, amount: number) => {
    return apiRequest<{ success: boolean; credits: number; message: string }>('/api/payments/verify', {
      method: 'POST',
      body: JSON.stringify({
        transactionReference,
        amount,
      }),
    });
  },
};

// Exam API functions  
export const examApi = {
  createExamAttempt: async (examData: any) => {
    return apiRequest<any>('/api/exam-attempts', {
      method: 'POST',
      body: JSON.stringify(examData),
    });
  },

  getUserExamAttempts: async (userId: string) => {
    return apiRequest<any[]>(`/api/exam-attempts/user/${userId}`);
  },
};