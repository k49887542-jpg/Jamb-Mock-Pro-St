import { auth } from "./firebase";
import { 
  signInWithRedirect, 
  signInWithPopup,
  getRedirectResult, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  User 
} from "firebase/auth";

const provider = new GoogleAuthProvider();
provider.addScope('email');
provider.addScope('profile');

export function signInWithGoogle() {
  // For Netlify deployment, use popup method with better error handling
  return signInWithPopup(auth, provider).catch((error) => {
    console.error("Google sign-in error:", error);
    // Provide more specific error information
    if (error.code === 'auth/popup-blocked') {
      throw new Error('Popup was blocked. Please allow popups and try again.');
    } else if (error.code === 'auth/cancelled-popup-request') {
      throw new Error('Sign-in was cancelled.');
    } else if (error.code === 'auth/unauthorized-domain') {
      throw new Error('Domain not authorized. Please check Firebase configuration.');
    }
    throw error;
  });
}

export function signInWithEmail(email: string, password: string) {
  return signInWithEmailAndPassword(auth, email, password);
}

export async function signUpWithEmail(email: string, password: string) {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  // Send email verification
  if (userCredential.user && !userCredential.user.emailVerified) {
    await sendEmailVerification(userCredential.user);
  }
  return userCredential;
}

export function sendVerificationEmail(user: User) {
  return sendEmailVerification(user);
}

export function resetPassword(email: string) {
  return sendPasswordResetEmail(auth, email);
}

export function signOut() {
  return firebaseSignOut(auth);
}

export async function handleRedirect() {
  try {
    const result = await getRedirectResult(auth);
    return result;
  } catch (error) {
    console.error("Error in handleRedirect:", error);
    throw error;
  }
}

export type { User };
