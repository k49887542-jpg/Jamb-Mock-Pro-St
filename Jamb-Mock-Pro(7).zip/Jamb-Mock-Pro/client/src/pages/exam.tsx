import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ExamInterface } from '@/components/exam-interface';
import { ExamSubjectSelection } from '@/components/exam-subject-selection';
import { PaymentModal } from '@/components/payment-modal';
import { useUser } from '@/hooks/use-user';
import { Badge } from '@/components/ui/badge';
import { Lock, CreditCard, Timer, BookOpen, AlertTriangle, Loader } from 'lucide-react';

type ExamStep = 'welcome' | 'payment' | 'subject-selection' | 'exam-started';

export default function ExamPage() {
  const [currentStep, setCurrentStep] = useState<ExamStep>('welcome');
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const { user: firebaseUser, loading, credits, hasExamCredits, creditsLoading } = useUser();

  const handleStartExamFlow = () => {
    if (hasExamCredits) {
      setCurrentStep('subject-selection');
    } else {
      setShowPaymentModal(true);
    }
  };

  const handlePaymentComplete = () => {
    setCurrentStep('subject-selection');
  };

  const handleStartExam = (subjects: string[]) => {
    setSelectedSubjects(subjects);
    setCurrentStep('exam-started');
  };

  const handleExitExam = () => {
    setCurrentStep('welcome');
    setSelectedSubjects([]);
  };

  const handleBackToWelcome = () => {
    setCurrentStep('welcome');
  };

  // Exam Interface
  if (currentStep === 'exam-started') {
    return <ExamInterface selectedSubjects={selectedSubjects} onExit={handleExitExam} />;
  }

  // Subject Selection
  if (currentStep === 'subject-selection') {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <ExamSubjectSelection
            onStartExam={handleStartExam}
            onBack={handleBackToWelcome}
          />
        </div>
      </div>
    );
  }

  // Welcome Screen
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-4">
              JAMB Mock Examination
            </h1>
            <p className="text-lg text-muted-foreground">
              Take a complete JAMB simulation with 180 questions in 2 hours
            </p>
          </div>

          {loading ? (
            <Card className="max-w-md mx-auto">
              <CardContent className="flex items-center justify-center py-8">
                <Loader className="w-8 h-8 animate-spin text-primary" />
                <span className="ml-2">Loading...</span>
              </CardContent>
            </Card>
          ) : !firebaseUser ? (
            <Card className="max-w-md mx-auto">
              <CardHeader className="text-center">
                <Lock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <CardTitle>Sign In Required</CardTitle>
                <CardDescription>
                  Please sign in to access the mock examination
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" onClick={() => window.location.reload()}>
                  Sign In
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Exam Features */}
              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="text-center pb-3">
                    <Timer className="w-8 h-8 mx-auto text-primary mb-2" />
                    <CardTitle className="text-lg">Timed Exam</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="text-2xl font-bold text-primary mb-1">3 Hours</div>
                    <p className="text-sm text-muted-foreground">
                      Real JAMB exam conditions with countdown timer
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="text-center pb-3">
                    <BookOpen className="w-8 h-8 mx-auto text-primary mb-2" />
                    <CardTitle className="text-lg">180 Questions</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="text-2xl font-bold text-primary mb-1">4 Subjects</div>
                    <p className="text-sm text-muted-foreground">
                      45 questions per subject, randomly shuffled
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="text-center pb-3">
                    <CreditCard className="w-8 h-8 mx-auto text-primary mb-2" />
                    <CardTitle className="text-lg">Pay Per Use</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="text-2xl font-bold text-primary mb-1">₦1,000</div>
                    <p className="text-sm text-muted-foreground">
                      One-time payment per exam attempt
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Exam Instructions */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-500" />
                    Exam Instructions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      Select exactly 4 subjects (Use of English is mandatory)
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      You have 3 hours to complete all 180 questions
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      Questions are randomly shuffled for each attempt
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      Once started, you cannot pause or restart the exam
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      Each attempt requires a new payment of ₦1,000
                    </li>
                  </ul>
                </CardContent>
              </Card>

              {/* Start Exam Button */}
              {/* Credits Display */}
              {creditsLoading ? (
                <Card className="text-center p-6">
                  <Loader className="w-6 h-6 animate-spin mx-auto" />
                  <p className="text-sm text-muted-foreground mt-2">Loading credits...</p>
                </Card>
              ) : (
                <Card className="text-center p-6">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <CreditCard className="w-5 h-5 text-primary" />
                    <span className="text-lg font-semibold">Exam Credits: {credits}</span>
                  </div>
                  {hasExamCredits ? (
                    <Badge variant="default" className="bg-green-100 text-green-800">
                      Ready to take exam
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                      Purchase credits to unlock exam
                    </Badge>
                  )}
                </Card>
              )}

              {/* Start Exam Button */}
              <div className="text-center">
                <Button
                  size="lg"
                  onClick={handleStartExamFlow}
                  className="px-8 py-4 text-lg"
                  data-testid="button-start-exam-flow"
                  disabled={creditsLoading}
                >
                  {hasExamCredits ? (
                    <>Start Mock Exam ({credits} credits available)</>
                  ) : (
                    <>
                      <Lock className="w-5 h-5 mr-2" />
                      Purchase Credits & Start Exam
                    </>
                  )}
                </Button>
                {!hasExamCredits && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Secure payment • ₦1,000 per exam attempt
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        onPaymentComplete={handlePaymentComplete}
      />
    </div>
  );
}