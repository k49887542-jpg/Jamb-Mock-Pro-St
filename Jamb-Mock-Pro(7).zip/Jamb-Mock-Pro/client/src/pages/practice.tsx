import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { JAMB_SUBJECTS } from "@/data/subjects";
import { getQuestionsBySubject, type Question } from "@/data/questions";
import { ChevronLeft, ChevronRight, X, CheckCircle, Clock } from "lucide-react";
import { Link } from "wouter";

export default function Practice() {
  const { user } = useAuth();
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [showExplanation, setShowExplanation] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const handleSubjectSelect = (subjectId: string) => {
    const subjectQuestions = getQuestionsBySubject(subjectId);
    setQuestions(subjectQuestions);
    setSelectedSubject(subjectId);
    setCurrentQuestionIndex(0);
    setSelectedAnswer("");
    setShowExplanation(false);
  };

  const handleAnswerSubmit = () => {
    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer("");
      setShowExplanation(false);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setSelectedAnswer("");
      setShowExplanation(false);
    }
  };

  const currentQuestion = questions[currentQuestionIndex];
  const selectedSubjectData = JAMB_SUBJECTS.find(s => s.id === selectedSubject);
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">Please sign in to access practice mode and track your progress.</p>
            <Link href="/">
              <Button className="bg-blue-600 hover:bg-blue-700" data-testid="button-go-home">
                Go to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!selectedSubject) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl">Select a Subject to Practice</CardTitle>
              <p className="text-gray-600">Choose from the available JAMB subjects below</p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {JAMB_SUBJECTS.map((subject) => (
                  <Card 
                    key={subject.id}
                    className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-blue-500"
                    onClick={() => handleSubjectSelect(subject.id)}
                    data-testid={`subject-card-${subject.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          {subject.icon === 'language' && <span className="text-blue-600">🗣️</span>}
                          {subject.icon === 'calculator' && <span className="text-blue-600">🧮</span>}
                          {subject.icon === 'atom' && <span className="text-blue-600">⚛️</span>}
                          {subject.icon === 'flask' && <span className="text-blue-600">🧪</span>}
                          {subject.icon === 'leaf' && <span className="text-blue-600">🍃</span>}
                          {subject.icon === 'university' && <span className="text-blue-600">🏛️</span>}
                          {subject.icon === 'trending-up' && <span className="text-blue-600">📈</span>}
                          {subject.icon === 'book' && <span className="text-blue-600">📚</span>}
                          {subject.icon === 'globe' && <span className="text-blue-600">🌍</span>}
                          {subject.icon === 'scroll' && <span className="text-blue-600">📜</span>}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{subject.name}</h3>
                          <p className="text-sm text-gray-500">100 Questions</p>
                          {subject.isCore && (
                            <Badge variant="secondary" className="mt-1">Core Subject</Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedSubjectData?.name} Practice
                </h3>
                <p className="text-gray-600">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-sm text-gray-600">
                  Progress: <span className="font-semibold">{Math.round(progress)}%</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedSubject(null)}
                  data-testid="button-exit-practice"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
            </div>
          </CardContent>
        </Card>

        {/* Question */}
        {currentQuestion && (
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="mb-6">
                <p className="text-lg text-gray-900 leading-relaxed">
                  {currentQuestion.questionText}
                </p>
              </div>

              <RadioGroup 
                value={selectedAnswer} 
                onValueChange={setSelectedAnswer}
                className="space-y-3"
              >
                {currentQuestion.options.map((option) => (
                  <div key={option.label} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.label} id={option.label} />
                    <Label 
                      htmlFor={option.label}
                      className="flex-1 p-4 border-2 border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer transition-colors"
                      data-testid={`option-${option.label}`}
                    >
                      <span className="font-medium text-gray-900 mr-2">{option.label}.</span>
                      <span className="text-gray-800">{option.text}</span>
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="mt-6 flex justify-between">
                <Button
                  variant="outline"
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                  data-testid="button-previous-question"
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                
                <div className="flex space-x-3">
                  {!showExplanation && (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={!selectedAnswer}
                      className="bg-blue-600 hover:bg-blue-700"
                      data-testid="button-submit-answer"
                    >
                      Submit Answer
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={handleNextQuestion}
                    disabled={currentQuestionIndex === questions.length - 1}
                    data-testid="button-next-question"
                  >
                    Next
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Answer Explanation */}
        {showExplanation && currentQuestion && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-green-900 mb-2">
                    Correct Answer: {currentQuestion.correctAnswer}
                  </h4>
                  <p className="text-green-800">{currentQuestion.explanation}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
