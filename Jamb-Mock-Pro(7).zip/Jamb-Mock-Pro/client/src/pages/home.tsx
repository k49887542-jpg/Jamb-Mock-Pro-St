import { HeroSection } from "@/components/hero-section";
import { ModeSelection } from "@/components/mode-selection";
import { FeaturesSection } from "@/components/features-section";

export default function Home() {
  return (
    <>
      <HeroSection />
      <ModeSelection />
      <FeaturesSection />
    </>
  );
}
