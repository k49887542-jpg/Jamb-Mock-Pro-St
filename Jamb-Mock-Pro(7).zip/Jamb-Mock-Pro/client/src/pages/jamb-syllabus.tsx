import { BookOpen, Download, Eye, CheckCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function JambSyllabus() {
  const subjects = [
    {
      name: "Use of English",
      topics: [
        "Comprehension", "Lexis and Structure", "Summary", "Oral Forms", 
        "Registers", "Punctuation and Spelling"
      ],
      description: "Grammar, vocabulary, comprehension, and language usage",
    },
    {
      name: "Mathematics", 
      topics: [
        "Number and Numeration", "Algebraic Processes", "Geometry and Trigonometry",
        "Statistics and Probability", "Calculus", "Mensuration"
      ],
      description: "Arithmetic, algebra, geometry, statistics, and basic calculus",
    },
    {
      name: "Physics",
      topics: [
        "Mechanics", "Heat", "Light", "Sound", "Electricity", "Modern Physics",
        "Atomic Structure", "Motion"
      ],
      description: "Classical and modern physics concepts and applications",
    },
    {
      name: "Chemistry", 
      topics: [
        "Physical Chemistry", "Organic Chemistry", "Inorganic Chemistry",
        "Analytical Chemistry", "Biochemistry", "Environmental Chemistry"
      ],
      description: "Chemical principles, reactions, and laboratory techniques",
    },
    {
      name: "Biology",
      topics: [
        "Cell Biology", "Genetics", "Evolution", "Ecology", "Plant Biology",
        "Animal Biology", "Human Biology", "Microbiology"
      ],
      description: "Life sciences covering plants, animals, and human biology",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">JAMB Syllabus</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Complete syllabus breakdown for all JAMB UTME subjects. Know exactly what topics to focus on for your preparation.
        </p>
      </div>

      {/* Quick Download Section */}
      <div className="bg-blue-50 rounded-lg p-6 mb-12 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Official JAMB Syllabus 2025</h2>
          <p className="text-gray-700 mb-4">
            Download the complete official syllabus directly from JAMB for detailed topic coverage
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Download className="h-4 w-4 mr-2" />
              Download Full Syllabus (PDF)
            </Button>
            <Button variant="outline">
              <Eye className="h-4 w-4 mr-2" />
              View Online
            </Button>
          </div>
        </div>
      </div>

      {/* Subject Breakdown */}
      <div className="space-y-8">
        <h2 className="text-3xl font-semibold text-gray-900 mb-6 text-center">Subject-wise Breakdown</h2>
        
        <div className="space-y-6">
          {subjects.map((subject, index) => (
            <Card key={subject.name} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{subject.name}</CardTitle>
                    <CardDescription className="mt-1">
                      {subject.description}
                    </CardDescription>
                  </div>
                  <Badge variant="outline">
                    {subject.topics.length} topics
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Key Topics Covered:</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {subject.topics.map((topic, topicIndex) => (
                        <div key={topicIndex} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{topic}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Detailed Syllabus
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      Practice Questions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Study Tips */}
      <div className="mt-16 bg-green-50 rounded-lg p-8">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6 text-center">
          How to Use the Syllabus Effectively
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Create a Study Plan</h3>
            <p className="text-gray-700 text-sm">
              Use the syllabus to create a comprehensive study schedule covering all topics systematically.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Focus on Weightings</h3>
            <p className="text-gray-700 text-sm">
              Pay attention to topics with higher question weightings in past JAMB examinations.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Download className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Track Progress</h3>
            <p className="text-gray-700 text-sm">
              Check off completed topics and monitor your coverage of the entire syllabus.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}