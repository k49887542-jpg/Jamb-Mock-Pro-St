import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { userApi, paymentApi } from '@/lib/api';
import { useToast } from './use-toast';

export function useUser() {
  const { user: firebaseUser, loading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch user data from backend
  const { data: user, isLoading: userLoading, error } = useQuery({
    queryKey: ['user'],
    queryFn: userApi.getCurrentUser,
    enabled: !!firebaseUser,
    retry: false,
  });

  // Fetch user credits
  const { data: creditsData, isLoading: creditsLoading } = useQuery({
    queryKey: ['user', 'credits'],
    queryFn: userApi.getUserCredits,
    enabled: !!firebaseUser,
    retry: false,
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: userApi.createUser,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      toast({
        title: 'Account created successfully!',
        description: 'Welcome to JAMB Mock Pro',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error creating account',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Payment verification mutation
  const verifyPaymentMutation = useMutation({
    mutationFn: ({ transactionRef, amount }: { transactionRef: string; amount: number }) =>
      paymentApi.verifyPayment(transactionRef, amount),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['user', 'credits'] });
      toast({
        title: 'Payment verified!',
        description: `${data.message}. You now have ${data.credits} exam credits.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Payment verification failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Auto-create user if Firebase user exists but backend user doesn't
  useEffect(() => {
    if (firebaseUser && error && !user && !createUserMutation.isPending) {
      createUserMutation.mutate({
        firebaseUid: firebaseUser.uid,
        email: firebaseUser.email!,
        displayName: firebaseUser.displayName,
        photoURL: firebaseUser.photoURL,
      });
    }
  }, [firebaseUser, error, user, createUserMutation]);

  const hasExamCredits = (creditsData?.credits || 0) > 0;
  
  return {
    user,
    firebaseUser,
    loading: authLoading || userLoading,
    creditsLoading,
    credits: creditsData?.credits || 0,
    hasExamCredits,
    verifyPayment: verifyPaymentMutation.mutate,
    isVerifyingPayment: verifyPaymentMutation.isPending,
    createUser: createUserMutation.mutate,
    isCreatingUser: createUserMutation.isPending,
  };
}