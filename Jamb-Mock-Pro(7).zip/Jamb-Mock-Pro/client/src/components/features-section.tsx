import { Brain, BarChart3, Clock, Smartphone, Lightbulb, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Brain,
    title: "Authentic Questions",
    description: "Practice with questions that mirror the actual JAMB UTME format and difficulty level.",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    icon: BarChart3,
    title: "Performance Tracking",
    description: "Monitor your progress with detailed analytics and identify areas for improvement.",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
  },
  {
    icon: Clock,
    title: "Timed Practice",
    description: "Experience real exam conditions with our timer-based mock examinations.",
    iconColor: "text-purple-600",
    bgColor: "bg-purple-100",
  },
  {
    icon: Smartphone,
    title: "Mobile Friendly",
    description: "Study anywhere, anytime with our responsive design that works on all devices.",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    icon: Lightbulb,
    title: "Detailed Explanations",
    description: "Learn from comprehensive explanations for every question in practice mode.",
    iconColor: "text-yellow-600",
    bgColor: "bg-yellow-100",
  },
  {
    icon: Users,
    title: "Community Support",
    description: "Join thousands of students preparing for JAMB and share study tips.",
    iconColor: "text-red-600",
    bgColor: "bg-red-100",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose JAMB Mock Pro?</h2>
          <p className="text-lg text-gray-600">Everything you need to excel in your JAMB UTME</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card key={index} className="bg-white border-none shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.bgColor} rounded-xl flex items-center justify-center mb-4`}>
                    <IconComponent className={`h-6 w-6 ${feature.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
