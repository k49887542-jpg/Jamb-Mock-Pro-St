import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Timer } from "@/components/ui/timer";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useUser } from "@/hooks/use-user";
import { useTimer } from "@/hooks/use-timer";
import { JAMB_SUBJECTS } from "@/data/subjects";
import { getExamQuestions, type Question } from "@/data/questions";
import { trackEvent } from "@/lib/analytics";
import { 
  Flag, 
  Pause, 
  Play, 
  ChevronLeft, 
  ChevronRight,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  ArrowLeft,
  Home
} from "lucide-react";

const EXAM_DURATION = 7200; // 2 hours in seconds (JAMB standard)

interface ExamInterfaceProps {
  selectedSubjects: string[];
  onExit: () => void;
}

export function ExamInterface({ selectedSubjects, onExit }: ExamInterfaceProps) {
  const { user } = useUser();
  const [examStarted, setExamStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<number>>(new Set());
  const [questions, setQuestions] = useState<Question[]>([]);
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [examResults, setExamResults] = useState<{
    totalCorrect: number;
    totalScore: number;
    subjectScores: Record<string, { correct: number; total: number; score: number }>;
  } | null>(null);

  const { timeRemaining, formattedTime, isRunning, start, pause, reset } = useTimer({
    initialTime: EXAM_DURATION,
    onTimeUp: () => {
      handleSubmitExam();
    },
  });

  useEffect(() => {
    if (examStarted && !questions.length) {
      // Use the selected subjects from the parent component
      const examQuestions = getExamQuestions(selectedSubjects);
      setQuestions(examQuestions);
    }
  }, [examStarted, questions.length, selectedSubjects]);

  useEffect(() => {
    // Load saved answer when navigating between questions
    setSelectedAnswer(answers[currentQuestionIndex] || "");
  }, [currentQuestionIndex, answers]);

  const handleStartExam = () => {
    trackEvent('exam_started', 'exam', 'mock_exam', selectedSubjects.length);
    setExamStarted(true);
    start();
  };

  const handleAnswerChange = (value: string) => {
    setSelectedAnswer(value);
    setAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: value
    }));
  };

  const handleNavigateToQuestion = (index: number) => {
    setCurrentQuestionIndex(index);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const toggleFlag = () => {
    setFlaggedQuestions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(currentQuestionIndex)) {
        newSet.delete(currentQuestionIndex);
      } else {
        newSet.add(currentQuestionIndex);
      }
      return newSet;
    });
  };

  const calculateResults = () => {
    const subjectRanges = {
      'use-of-english': { start: 0, end: 60 },
      'mathematics': { start: 60, end: 100 },
      'physics': { start: 100, end: 140 },
      'chemistry': { start: 140, end: 180 }
    };

    const subjectScores: Record<string, { correct: number; total: number; score: number }> = {};
    let totalCorrect = 0;

    Object.entries(subjectRanges).forEach(([subject, range]) => {
      let correct = 0;
      const total = range.end - range.start;
      
      for (let i = range.start; i < range.end; i++) {
        if (questions[i] && answers[i] === questions[i].correctAnswer) {
          correct++;
        }
      }
      
      totalCorrect += correct;
      const score = Math.round((correct / total) * 100); // 100 marks per subject
      subjectScores[subject] = { correct, total, score };
    });

    const totalScore = (totalCorrect / questions.length) * 400; // JAMB scoring out of 400

    return {
      totalCorrect,
      totalScore: Math.round(totalScore),
      subjectScores
    };
  };

  const handleSubmitExam = () => {
    const results = calculateResults();
    setExamResults(results);
    setExamSubmitted(true);
    pause();
    
    // Track exam completion with performance metrics
    trackEvent('exam_completed', 'exam', 'mock_exam', results.totalScore);
    trackEvent('exam_score', 'performance', 'total_score', results.totalScore);
  };

  const handleRestartExam = () => {
    setExamStarted(false);
    setExamSubmitted(false);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setFlaggedQuestions(new Set());
    setQuestions([]);
    setExamResults(null);
    reset();
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progress = questions.length > 0 ? ((currentQuestionIndex + 1) / questions.length) * 100 : 0;

  // Get current subject
  let currentSubject = '';
  let questionInSubject = 0;
  if (currentQuestionIndex < 60) {
    currentSubject = 'Use of English';
    questionInSubject = currentQuestionIndex + 1;
  } else if (currentQuestionIndex < 100) {
    currentSubject = 'Mathematics';
    questionInSubject = currentQuestionIndex - 59;
  } else if (currentQuestionIndex < 140) {
    currentSubject = 'Physics';
    questionInSubject = currentQuestionIndex - 99;
  } else {
    currentSubject = 'Chemistry';
    questionInSubject = currentQuestionIndex - 139;
  }

  const getQuestionStatus = (index: number) => {
    if (index === currentQuestionIndex) return 'current';
    if (answers[index]) return 'answered';
    if (flaggedQuestions.has(index)) return 'flagged';
    return 'unattempted';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'current': return 'bg-blue-600 text-white';
      case 'answered': return 'bg-green-600 text-white';
      case 'flagged': return 'bg-yellow-600 text-white';
      default: return 'bg-gray-600 text-gray-300';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">Please sign in to access exam mode.</p>
            <Button onClick={onExit} className="bg-blue-600 hover:bg-blue-700">
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (examSubmitted && examResults) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl text-green-600 mb-4">
                <CheckCircle className="h-8 w-8 mx-auto mb-2" />
                Exam Completed!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Overall Score */}
              <div className="text-center bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                <div className="text-4xl font-bold text-blue-600 mb-2">
                  {examResults.totalScore}/400
                </div>
                <div className="text-lg text-gray-700">
                  {examResults.totalCorrect}/180 questions correct
                </div>
                <div className="text-sm text-gray-600">
                  {Math.round((examResults.totalCorrect / 180) * 100)}% accuracy
                </div>
              </div>

              {/* Subject Breakdown */}
              <div className="grid md:grid-cols-2 gap-4">
                {Object.entries(examResults.subjectScores).map(([subject, score]) => {
                  const subjectName = JAMB_SUBJECTS.find(s => s.id === subject)?.name || subject;
                  return (
                    <Card key={subject} className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-semibold">{subjectName}</h4>
                        <Badge variant={score.score >= 70 ? "default" : score.score >= 50 ? "secondary" : "destructive"}>
                          {score.score}/100
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        {score.correct}/{score.total} correct ({Math.round((score.correct / score.total) * 100)}%)
                      </div>
                      <Progress value={(score.correct / score.total) * 100} className="mt-2" />
                    </Card>
                  );
                })}
              </div>

              {/* Performance Analysis */}
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-semibold">Performance Analysis:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {examResults.totalScore >= 250 && (
                        <li className="text-green-600">Excellent performance! You're well-prepared for JAMB.</li>
                      )}
                      {examResults.totalScore >= 200 && examResults.totalScore < 250 && (
                        <li className="text-blue-600">Good performance! Continue practicing to improve further.</li>
                      )}
                      {examResults.totalScore < 200 && (
                        <li className="text-red-600">More practice needed. Focus on your weaker subjects.</li>
                      )}
                      <li>
                        Answered {Object.keys(answers).length} out of 180 questions
                      </li>
                      <li>
                        Flagged {flaggedQuestions.size} questions for review
                      </li>
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>

              <div className="flex justify-center space-x-4">
                <Button onClick={onExit} className="bg-blue-600 hover:bg-blue-700">
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!examStarted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl flex items-center">
                  <FileText className="h-6 w-6 mr-2" />
                  JAMB UTME Mock Examination
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onExit}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back to Home
                </Button>
              </div>
              <p className="text-gray-600">
                This is a complete simulation of the JAMB UTME examination format
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3 flex items-center">
                    <Clock className="h-4 w-4 mr-2" />
                    Exam Structure:
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Total Questions: 180</li>
                    <li>• Duration: 2 hours (120 minutes)</li>
                    <li>• Use of English: 60 questions (100 marks)</li>
                    <li>• Mathematics: 40 questions (100 marks)</li>
                    <li>• Physics: 40 questions (100 marks)</li>
                    <li>• Chemistry: 40 questions (100 marks)</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3 flex items-center">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Instructions:
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Select only one answer per question</li>
                    <li>• You can flag questions for review</li>
                    <li>• Timer will auto-submit when it expires</li>
                    <li>• Your progress is automatically saved</li>
                    <li>• You can pause and resume the exam</li>
                    <li>• Navigate freely between questions</li>
                  </ul>
                </div>
              </div>
              
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Important:</strong> Once you start the exam, the timer will begin. 
                  Make sure you have a stable internet connection and enough time to complete the exam.
                </AlertDescription>
              </Alert>
              
              <div className="text-center">
                <Button
                  onClick={handleStartExam}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-4"
                  data-testid="button-start-exam"
                >
                  Start Exam
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Exam Header */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onExit}
                  className="text-gray-300 hover:text-white hover:bg-gray-700"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back
                </Button>
                <div>
                  <h2 className="text-2xl font-bold mb-2 text-white">JAMB UTME Mock Examination</h2>
                  <p className="text-gray-300">180 Questions • 4 Subjects • Total Score: 400 marks</p>
                </div>
              </div>
              <div className="text-right">
                <Timer 
                  time={formattedTime}
                  isRunning={isRunning}
                  variant={timeRemaining < 600 ? "danger" : "default"}
                />
                <div className="text-sm text-gray-400">Time Remaining</div>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Progress</span>
                <span>{currentQuestionIndex + 1}/180 Questions</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Question Navigation Panel */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-800 border-gray-700 sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4 text-white">Question Navigation</h3>
                <div className="space-y-4">
                  {/* Use of English */}
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Use of English (1-60)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 60}, (_, i) => (
                        <button
                          key={i}
                          onClick={() => handleNavigateToQuestion(i)}
                          className={`w-6 h-6 text-xs rounded font-medium transition-colors ${getStatusColor(getQuestionStatus(i))}`}
                          data-testid={`nav-question-${i + 1}`}
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  {/* Mathematics */}
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Mathematics (61-100)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 60}
                          onClick={() => handleNavigateToQuestion(i + 60)}
                          className={`w-6 h-6 text-xs rounded font-medium transition-colors ${getStatusColor(getQuestionStatus(i + 60))}`}
                          data-testid={`nav-question-${i + 61}`}
                        >
                          {i + 61}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Physics */}
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Physics (101-140)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 100}
                          onClick={() => handleNavigateToQuestion(i + 100)}
                          className={`w-6 h-6 text-xs rounded font-medium transition-colors ${getStatusColor(getQuestionStatus(i + 100))}`}
                          data-testid={`nav-question-${i + 101}`}
                        >
                          {i + 101}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Chemistry */}
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Chemistry (141-180)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 140}
                          onClick={() => handleNavigateToQuestion(i + 140)}
                          className={`w-6 h-6 text-xs rounded font-medium transition-colors ${getStatusColor(getQuestionStatus(i + 140))}`}
                          data-testid={`nav-question-${i + 141}`}
                        >
                          {i + 141}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 space-y-2 text-sm">
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-blue-600 rounded mr-2"></div>
                    <span className="text-gray-300">Current</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-green-600 rounded mr-2"></div>
                    <span className="text-gray-300">Answered</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-yellow-600 rounded mr-2"></div>
                    <span className="text-gray-300">Flagged</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-gray-600 rounded mr-2"></div>
                    <span className="text-gray-300">Not Attempted</span>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-700 text-sm text-gray-300">
                  <div>Answered: {Object.keys(answers).length}/{questions.length}</div>
                  <div>Flagged: {flaggedQuestions.size}</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Question Area */}
          <div className="lg:col-span-3">
            {currentQuestion && (
              <Card className="bg-gray-800 border-gray-700 mb-6">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <Badge className="bg-blue-600 text-white">{currentSubject}</Badge>
                      <span className="text-gray-400">
                        Question {questionInSubject} of {currentSubject === 'Use of English' ? 60 : 40}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold mb-4 text-white">
                      Question {currentQuestionIndex + 1}
                      {flaggedQuestions.has(currentQuestionIndex) && (
                        <Flag className="h-4 w-4 text-yellow-500 inline ml-2" />
                      )}
                    </h3>
                  </div>

                  <div className="text-lg text-gray-100 mb-8 leading-relaxed">
                    {currentQuestion.questionText}
                  </div>

                  <RadioGroup
                    value={selectedAnswer}
                    onValueChange={handleAnswerChange}
                    className="space-y-4"
                  >
                    {currentQuestion.options.map((option) => (
                      <div key={option.label} className="flex items-center space-x-2">
                        <RadioGroupItem value={option.label} id={option.label} />
                        <Label
                          htmlFor={option.label}
                          className="flex-1 p-4 border-2 border-gray-600 rounded-lg hover:border-blue-500 cursor-pointer transition-colors"
                          data-testid={`exam-option-${option.label}`}
                        >
                          <span className="font-medium text-white mr-2">{option.label}.</span>
                          <span className="text-gray-200">{option.text}</span>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>

                  <div className="mt-8 flex justify-between">
                    <Button
                      variant="outline"
                      onClick={handlePreviousQuestion}
                      disabled={currentQuestionIndex === 0}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      data-testid="button-exam-previous"
                    >
                      <ChevronLeft className="h-4 w-4 mr-2" />
                      Previous
                    </Button>
                    
                    <div className="flex space-x-3">
                      <Button
                        variant="outline"
                        onClick={toggleFlag}
                        className={`border-gray-600 hover:bg-gray-700 ${
                          flaggedQuestions.has(currentQuestionIndex) 
                            ? 'bg-yellow-600 text-white border-yellow-600' 
                            : 'text-gray-300'
                        }`}
                        data-testid="button-flag-question"
                      >
                        <Flag className="h-4 w-4 mr-2" />
                        {flaggedQuestions.has(currentQuestionIndex) ? 'Unflag' : 'Flag'}
                      </Button>
                      <Button
                        onClick={handleNextQuestion}
                        disabled={currentQuestionIndex === questions.length - 1}
                        className="bg-blue-600 hover:bg-blue-700"
                        data-testid="button-exam-next"
                      >
                        Save & Next
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Exam Controls */}
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="flex space-x-4">
                    <Button
                      onClick={handleSubmitExam}
                      className="bg-red-600 hover:bg-red-700"
                      data-testid="button-submit-exam"
                    >
                      Submit Exam
                    </Button>
                    <Button
                      variant="outline"
                      onClick={isRunning ? pause : start}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      data-testid="button-pause-resume"
                    >
                      {isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                      {isRunning ? 'Pause' : 'Resume'}
                    </Button>
                  </div>
                  <div className="text-gray-400 text-sm flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    Auto-save enabled • Answered: {Object.keys(answers).length}/{questions.length}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
