import { Button } from "@/components/ui/button";
import { TrendingUp, Users, BookOpen, Award } from "lucide-react";
import { Link } from "wouter";

export function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-blue-50 to-blue-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Master Your <span className="text-blue-600">JAMB UTME</span> with Nigeria's #1 Mock Platform
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Practice with authentic questions, take timed exams, and track your progress. Join thousands of students achieving their university dreams.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/practice">
                <Button 
                  size="lg"
                  className="bg-blue-600 text-white hover:bg-blue-700 text-lg px-8 py-4"
                  data-testid="button-start-practice"
                >
                  Start Free Practice
                </Button>
              </Link>
              <Link href="/exam">
                <Button 
                  variant="outline"
                  size="lg"
                  className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50 text-lg px-8 py-4"
                  data-testid="button-mock-exam"
                >
                  View Mock Exam
                </Button>
              </Link>
            </div>
            
            <div className="mt-8 grid grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600 flex items-center justify-center">
                  <Users className="h-6 w-6 mr-1" />
                  50k+
                </div>
                <div className="text-sm text-gray-600">Students</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600 flex items-center justify-center">
                  <BookOpen className="h-6 w-6 mr-1" />
                  10k+
                </div>
                <div className="text-sm text-gray-600">Questions</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600 flex items-center justify-center">
                  <Award className="h-6 w-6 mr-1" />
                  98%
                </div>
                <div className="text-sm text-gray-600">Success Rate</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Students studying together"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Real JAMB Format</div>
                  <div className="text-sm text-gray-600">180 Questions • 2 Hours</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
