import { Download, Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePWA } from '@/hooks/use-pwa';
import { trackEvent } from '@/lib/analytics';

export function InstallAppButton() {
  const { isInstallable, isInstalled, installApp } = usePWA();

  if (isInstalled) {
    return (
      <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
        <Smartphone className="h-4 w-4" />
        <span>App Installed</span>
      </div>
    );
  }

  if (!isInstallable) {
    return null;
  }

  const handleInstall = () => {
    trackEvent('app_install_initiated', 'app', 'pwa_install');
    installApp();
  };

  return (
    <Button
      onClick={handleInstall}
      variant="outline"
      size="sm"
      className="gap-2 bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-300"
    >
      <Download className="h-4 w-4" />
      Install App
    </Button>
  );
}