const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');

// Import your existing server routes
const app = express();

// Enable CORS for all origins in development
app.use(cors({
  origin: true,
  credentials: true
}));

app.use(express.json());

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'JAMB Mock Pro API is running on Netlify' });
});

// Import and use your existing routes
// Note: You'll need to adapt your existing server code
app.get('/api/subjects', (req, res) => {
  // Return subjects data
  const subjects = [
    { id: 'english', name: 'Use of English', questionCount: 60 },
    { id: 'mathematics', name: 'Mathematics', questionCount: 40 },
    { id: 'physics', name: 'Physics', questionCount: 40 },
    { id: 'chemistry', name: 'Chemistry', questionCount: 40 },
    { id: 'biology', name: 'Biology', questionCount: 40 }
  ];
  res.json(subjects);
});

// Catch-all handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'API endpoint not found' });
});

module.exports.handler = serverless(app);