import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jambmockpro.app',
  appName: 'JAMB Mock Pro',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https'
  },
  android: {
    buildOptions: {
      signingType: 'jarsigner'
    }
  },
  plugins: {
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#2563eb'
    },
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#2563eb',
      showSpinner: false
    }
  }
};

export default config;
