# JAMB Mock Pro - Android App

Nigeria's Premier JAMB UTME Preparation Platform - Now available as a native Android app!

## 📱 Download Android APK

**Latest Release:** [Download APK](../../releases/latest)

The APK is automatically built and updated with every code change. Download the latest version from the releases section.

## ✨ Features

- **Practice Mode**: Study with detailed explanations
- **Mock Exams**: Timed 2-hour practice tests
- **Performance Analytics**: Track your progress
- **Offline Support**: Practice questions work without internet
- **All Subjects**: English, Mathematics, Physics, Chemistry, Biology

## 🚀 Installation

### For Android Users:
1. Download the APK from [Releases](../../releases/latest)
2. Enable "Install from unknown sources" in Android settings
3. Tap the downloaded APK file
4. Follow installation prompts
5. Open "JAMB Mock Pro" from your app drawer

### For Developers:
```bash
# Clone the repository
git clone [your-repo-url]
cd jamb-mock-pro

# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Build Android APK (requires Android Studio)
cd android
./gradlew assembleDebug
```

## 🏗️ Architecture

- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + Node.js
- **Mobile**: Capacitor (native Android wrapper)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Firebase Auth with Google OAuth
- **Styling**: Tailwind CSS + shadcn/ui components

## 📦 Build Process

This project uses GitHub Actions for automatic APK building:

- **Every Push**: Builds and tests the APK
- **Main Branch**: Creates a new release with downloadable APK
- **Versioning**: Automatic version numbering based on build date

## 🎯 Google Play Store

This app is configured for Google Play Store distribution:
- **Package ID**: `com.jambmockpro.app`
- **Signing**: Ready for release signing
- **Permissions**: Minimal (internet access only)
- **Category**: Education

## 📊 Development Status

- ✅ Web Application: Complete
- ✅ Android Conversion: Complete
- ✅ APK Building: Automated via GitHub Actions
- ✅ Play Store Ready: Package configured
- ⏳ Store Submission: Pending

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Create a pull request

## 📄 License

This project is licensed under the MIT License.

---

**Built with ❤️ for Nigerian students preparing for JAMB UTME**