import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface TimerProps {
  time: string;
  isRunning: boolean;
  className?: string;
  variant?: "default" | "danger";
}

export function Timer({ time, isRunning, className, variant = "default" }: TimerProps) {
  return (
    <div className={cn(
      "flex items-center space-x-2 font-mono",
      variant === "danger" && "text-red-400",
      variant === "default" && "text-white",
      className
    )}>
      <Clock className={cn(
        "h-5 w-5",
        isRunning && "animate-pulse"
      )} />
      <span className="text-2xl font-bold">{time}</span>
    </div>
  );
}
