import { useState } from 'react';
import { HCaptchaWrapper } from './hcaptcha-wrapper';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, CheckCircle } from 'lucide-react';
import { trackEvent } from '@/lib/analytics';

interface CaptchaProtectionProps {
  onVerified: () => void;
  title?: string;
  description?: string;
  className?: string;
}

export function CaptchaProtection({ 
  onVerified, 
  title = "Security Verification Required",
  description = "Please complete the verification to continue",
  className = ""
}: CaptchaProtectionProps) {
  const [isVerified, setIsVerified] = useState(false);
  const [captchaToken, setCaptchaToken] = useState<string>("");

  const handleCaptchaVerify = (token: string) => {
    setCaptchaToken(token);
    setIsVerified(true);
    trackEvent('captcha_verified', 'security', 'protection_component');
  };

  const handleCaptchaExpire = () => {
    setCaptchaToken("");
    setIsVerified(false);
  };

  const handleProceed = () => {
    if (isVerified && captchaToken) {
      onVerified();
    }
  };

  return (
    <Card className={`max-w-md mx-auto ${className}`}>
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
          {isVerified ? (
            <CheckCircle className="h-6 w-6 text-green-600" />
          ) : (
            <Shield className="h-6 w-6 text-blue-600" />
          )}
        </div>
        <CardTitle className="text-xl">{title}</CardTitle>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <HCaptchaWrapper
          onVerify={handleCaptchaVerify}
          onExpire={handleCaptchaExpire}
          size="normal"
          theme="light"
        />
        
        {isVerified && (
          <Button 
            onClick={handleProceed}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Continue Securely
          </Button>
        )}
      </CardContent>
    </Card>
  );
}