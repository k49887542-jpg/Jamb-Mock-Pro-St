import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Clock, Check, Users } from "lucide-react";
import { Link } from "wouter";

export function ModeSelection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Study Mode</h2>
          <p className="text-lg text-gray-600">Practice freely or take a full mock exam experience</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Practice Mode Card */}
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100 hover:shadow-lg transition-shadow">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mr-4">
                  <BookOpen className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Practice Mode</h3>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">FREE</Badge>
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-green-500 mr-3" />
                  100 questions per subject
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-green-500 mr-3" />
                  Detailed explanations
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-green-500 mr-3" />
                  Immediate feedback
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-green-500 mr-3" />
                  No time pressure
                </li>
              </ul>
              
              <Link href="/practice">
                <Button 
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                  data-testid="button-start-practice-mode"
                >
                  Start Practice
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Exam Mode Card */}
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mr-4">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Exam Mode</h3>
                  <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">PREMIUM</Badge>
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-blue-500 mr-3" />
                  Full JAMB simulation (180 questions)
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-blue-500 mr-3" />
                  2-hour timed exam
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-blue-500 mr-3" />
                  Real CBT interface
                </li>
                <li className="flex items-center text-gray-700">
                  <Check className="h-5 w-5 text-blue-500 mr-3" />
                  Performance analytics
                </li>
              </ul>
              
              <Link href="/exam">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  data-testid="button-start-exam-mode"
                >
                  Take Mock Exam
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
