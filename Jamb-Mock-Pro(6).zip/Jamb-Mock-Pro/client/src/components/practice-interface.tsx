import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useUser } from "@/hooks/use-user";
import { JAMB_SUBJECTS } from "@/data/subjects";
import { getQuestionsBySubject, type Question } from "@/data/questions";
import { trackEvent } from "@/lib/analytics";
import { 
  ChevronLeft, 
  ChevronRight, 
  X, 
  CheckCircle, 
  Languages,
  Calculator,
  Atom,
  FlaskConical,
  Building2,
  TrendingUp,
  BookOpen,
  Globe,
  ScrollText
} from "lucide-react";

const subjectIcons = {
  "language": Languages,
  "calculator": Calculator,
  "atom": Atom,
  "flask": FlaskConical,
  "university": Building2,
  "trending-up": TrendingUp,
  "book": BookOpen,
  "globe": Globe,
  "scroll": ScrollText,
};

interface PracticeInterfaceProps {
  selectedSubject?: string;
  onSubjectSelect: (subjectId: string) => void;
  onExit: () => void;
}

export function PracticeInterface({ 
  selectedSubject, 
  onSubjectSelect, 
  onExit 
}: PracticeInterfaceProps) {
  const { user } = useUser();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [showExplanation, setShowExplanation] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [correctAnswers, setCorrectAnswers] = useState<Record<number, boolean>>({});

  useEffect(() => {
    if (selectedSubject) {
      const subjectQuestions = getQuestionsBySubject(selectedSubject);
      setQuestions(subjectQuestions);
      setCurrentQuestionIndex(0);
      setSelectedAnswer("");
      setShowExplanation(false);
      setUserAnswers({});
      setCorrectAnswers({});
    }
  }, [selectedSubject]);

  useEffect(() => {
    // Load saved answer when navigating between questions
    if (userAnswers[currentQuestionIndex]) {
      setSelectedAnswer(userAnswers[currentQuestionIndex]);
    } else {
      setSelectedAnswer("");
    }
    setShowExplanation(false);
  }, [currentQuestionIndex, userAnswers]);

  const handleAnswerSubmit = () => {
    if (!selectedAnswer || !questions[currentQuestionIndex]) return;
    
    const isCorrect = selectedAnswer === questions[currentQuestionIndex].correctAnswer;
    
    setUserAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: selectedAnswer
    }));
    
    setCorrectAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: isCorrect
    }));
    
    setShowExplanation(true);
    
    // Track practice question answered
    trackEvent('practice_question_answered', 'practice', selectedSubject, isCorrect ? 1 : 0);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const currentQuestion = questions[currentQuestionIndex];
  const selectedSubjectData = JAMB_SUBJECTS.find(s => s.id === selectedSubject);
  const progress = questions.length > 0 ? ((currentQuestionIndex + 1) / questions.length) * 100 : 0;
  const answeredQuestions = Object.keys(userAnswers).length;
  const correctCount = Object.values(correctAnswers).filter(Boolean).length;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">
              Please sign in to access practice mode and track your progress.
            </p>
            <Button onClick={onExit} className="bg-blue-600 hover:bg-blue-700">
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!selectedSubject) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl">Select a Subject to Practice</CardTitle>
              <p className="text-gray-600">Choose from the available JAMB subjects below</p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {JAMB_SUBJECTS.map((subject) => {
                  const IconComponent = subjectIcons[subject.icon as keyof typeof subjectIcons] || BookOpen;
                  return (
                    <Card 
                      key={subject.id}
                      className="cursor-pointer hover:shadow-md transition-all border-2 hover:border-blue-500 hover:scale-105"
                      onClick={() => {
                        trackEvent('practice_subject_selected', 'practice', subject.id);
                        onSubjectSelect(subject.id);
                      }}
                      data-testid={`subject-card-${subject.id}`}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <IconComponent className="h-5 w-5 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{subject.name}</h3>
                            <p className="text-sm text-gray-500">100 Questions</p>
                            {subject.isCore && (
                              <Badge variant="secondary" className="mt-1">Core Subject</Badge>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedSubjectData?.name} Practice
                </h3>
                <p className="text-gray-600">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </p>
                <div className="text-sm text-gray-500 mt-1">
                  Answered: {answeredQuestions} | Correct: {correctCount} | Score: {answeredQuestions > 0 ? Math.round((correctCount / answeredQuestions) * 100) : 0}%
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-sm text-gray-600">
                  Progress: <span className="font-semibold">{Math.round(progress)}%</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onExit}
                  data-testid="button-exit-practice"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={progress} className="w-full" />
            </div>
          </CardContent>
        </Card>

        {/* Question */}
        {currentQuestion && (
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <Badge 
                    variant="outline" 
                    className={`${
                      currentQuestion.difficulty === 'easy' ? 'border-green-500 text-green-700' :
                      currentQuestion.difficulty === 'medium' ? 'border-yellow-500 text-yellow-700' :
                      'border-red-500 text-red-700'
                    }`}
                  >
                    {currentQuestion.difficulty.toUpperCase()}
                  </Badge>
                  {currentQuestion.year && (
                    <Badge variant="secondary">{currentQuestion.year}</Badge>
                  )}
                </div>
                <p className="text-lg text-gray-900 leading-relaxed">
                  {currentQuestion.questionText}
                </p>
              </div>

              <RadioGroup 
                value={selectedAnswer} 
                onValueChange={setSelectedAnswer}
                className="space-y-3"
                disabled={showExplanation}
              >
                {currentQuestion.options.map((option) => (
                  <div key={option.label} className="flex items-center space-x-2">
                    <RadioGroupItem value={option.label} id={option.label} />
                    <Label 
                      htmlFor={option.label}
                      className={`flex-1 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                        showExplanation 
                          ? option.label === currentQuestion.correctAnswer
                            ? 'border-green-500 bg-green-50'
                            : selectedAnswer === option.label && selectedAnswer !== currentQuestion.correctAnswer
                            ? 'border-red-500 bg-red-50'
                            : 'border-gray-200'
                          : selectedAnswer === option.label
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                      data-testid={`option-${option.label}`}
                    >
                      <span className="font-medium text-gray-900 mr-2">{option.label}.</span>
                      <span className="text-gray-800">{option.text}</span>
                      {showExplanation && option.label === currentQuestion.correctAnswer && (
                        <CheckCircle className="h-4 w-4 text-green-600 ml-2 inline" />
                      )}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="mt-6 flex justify-between">
                <Button
                  variant="outline"
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                  data-testid="button-previous-question"
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                
                <div className="flex space-x-3">
                  {!showExplanation && (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={!selectedAnswer}
                      className="bg-blue-600 hover:bg-blue-700"
                      data-testid="button-submit-answer"
                    >
                      Submit Answer
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    onClick={handleNextQuestion}
                    disabled={currentQuestionIndex === questions.length - 1}
                    data-testid="button-next-question"
                  >
                    Next
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Answer Explanation */}
        {showExplanation && currentQuestion && (
          <Alert className={`${
            correctAnswers[currentQuestionIndex] 
              ? 'border-green-200 bg-green-50' 
              : 'border-red-200 bg-red-50'
          }`}>
            <CheckCircle className={`h-4 w-4 ${
              correctAnswers[currentQuestionIndex] ? 'text-green-600' : 'text-red-600'
            }`} />
            <AlertDescription>
              <div className="space-y-2">
                <div className={`font-semibold ${
                  correctAnswers[currentQuestionIndex] ? 'text-green-900' : 'text-red-900'
                }`}>
                  {correctAnswers[currentQuestionIndex] ? 'Correct!' : 'Incorrect'} 
                  {" "}Answer: {currentQuestion.correctAnswer}
                </div>
                <p className={`${
                  correctAnswers[currentQuestionIndex] ? 'text-green-800' : 'text-red-800'
                }`}>
                  {currentQuestion.explanation}
                </p>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Practice Summary */}
        {answeredQuestions > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Practice Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{answeredQuestions}</div>
                  <div className="text-sm text-gray-600">Attempted</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{correctCount}</div>
                  <div className="text-sm text-gray-600">Correct</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">
                    {answeredQuestions > 0 ? Math.round((correctCount / answeredQuestions) * 100) : 0}%
                  </div>
                  <div className="text-sm text-gray-600">Accuracy</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
