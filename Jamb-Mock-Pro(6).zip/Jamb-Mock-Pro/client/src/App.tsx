import { Switch, Route } from "wouter";
import { useState, useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { AuthModal } from "@/components/auth-modal";
import { handleRedirect } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";
import Home from "@/pages/home";
import Practice from "@/pages/practice";
import Exam from "@/pages/exam";
import Analytics from "@/pages/analytics";
import Terms from "@/pages/terms";
import Privacy from "@/pages/privacy";
import ContactUs from "@/pages/contact-us";
import SubjectPractice from "@/pages/subject-practice";
import PastQuestions from "@/pages/past-questions";
import JambSyllabus from "@/pages/jamb-syllabus";
import StudyTips from "@/pages/study-tips";
import UniversityGuide from "@/pages/university-guide";
import CourseRequirements from "@/pages/course-requirements";
import HelpCenter from "@/pages/help-center";
import NotFound from "@/pages/not-found";

function Router() {
  // Track page views when routes change
  useAnalytics();
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/practice" component={Practice} />
      <Route path="/exam" component={Exam} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/subject-practice" component={SubjectPractice} />
      <Route path="/past-questions" component={PastQuestions} />
      <Route path="/jamb-syllabus" component={JambSyllabus} />
      <Route path="/study-tips" component={StudyTips} />
      <Route path="/university-guide" component={UniversityGuide} />
      <Route path="/course-requirements" component={CourseRequirements} />
      <Route path="/help-center" component={HelpCenter} />
      <Route path="/contact-us" component={ContactUs} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { toast } = useToast();

  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Verify required environment variable is present
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      initGA();
    }
  }, []);

  // Handle Google sign-in redirect on app load (for fallback redirect cases)
  useEffect(() => {
    const checkGoogleRedirect = async () => {
      try {
        const result = await handleRedirect();
        if (result && result.user) {
          setIsAuthModalOpen(false); // Close auth modal if open
          toast({
            title: "Welcome!",
            description: `Signed in as ${result.user.displayName || result.user.email}`,
          });
        }
      } catch (error: any) {
        console.error("Redirect handling error:", error);
        if (error.code === 'auth/unauthorized-domain') {
          toast({
            title: "Domain Authorization Required",
            description: "Please add this domain to Firebase authorized domains.",
            variant: "destructive",
          });
        }
      }
    };

    checkGoogleRedirect();
  }, [toast]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen flex flex-col">
          <Navigation onSignIn={() => setIsAuthModalOpen(true)} />
          <main className="flex-1">
            <Router />
          </main>
          <Footer />
        </div>
        <AuthModal 
          isOpen={isAuthModalOpen} 
          onClose={() => setIsAuthModalOpen(false)} 
        />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
