import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Timer } from "@/components/ui/timer";
import { useAuth } from "@/hooks/use-auth";
import { useTimer } from "@/hooks/use-timer";
import { JAMB_SUBJECTS } from "@/data/subjects";
import { getExamQuestions, type Question } from "@/data/questions";
import { Flag, Pause, Play, ChevronLeft, ChevronRight } from "lucide-react";

const EXAM_DURATION = 7200; // 2 hours in seconds

export default function Exam() {
  const { user } = useAuth();
  const [examStarted, setExamStarted] = useState(false);
  const [examCompleted, setExamCompleted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<number>>(new Set());
  const [questions, setQuestions] = useState<Question[]>([]);

  const { timeRemaining, formattedTime, isRunning, start, pause } = useTimer({
    initialTime: EXAM_DURATION,
    onTimeUp: () => {
      handleSubmitExam();
    },
  });

  useEffect(() => {
    if (examStarted && !questions.length) {
      // Default exam subjects (English + Math + Physics + Chemistry)
      const examSubjects = ['use-of-english', 'mathematics', 'physics', 'chemistry'];
      const examQuestions = getExamQuestions(examSubjects);
      setQuestions(examQuestions);
    }
  }, [examStarted, questions.length]);

  const handleStartExam = () => {
    setExamStarted(true);
    start();
  };

  const handleAnswerChange = (value: string) => {
    setSelectedAnswer(value);
    setAnswers(prev => ({
      ...prev,
      [currentQuestionIndex]: value
    }));
  };

  const handleNavigateToQuestion = (index: number) => {
    setCurrentQuestionIndex(index);
    setSelectedAnswer(answers[index] || "");
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(answers[currentQuestionIndex + 1] || "");
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setSelectedAnswer(answers[currentQuestionIndex - 1] || "");
    }
  };

  const toggleFlag = () => {
    setFlaggedQuestions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(currentQuestionIndex)) {
        newSet.delete(currentQuestionIndex);
      } else {
        newSet.add(currentQuestionIndex);
      }
      return newSet;
    });
  };

  const handleSubmitExam = () => {
    setExamCompleted(true);
    pause();
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  // Get current subject
  let currentSubject = '';
  if (currentQuestionIndex < 60) {
    currentSubject = 'Use of English';
  } else if (currentQuestionIndex < 100) {
    currentSubject = 'Mathematics';
  } else if (currentQuestionIndex < 140) {
    currentSubject = 'Physics';
  } else {
    currentSubject = 'Chemistry';
  }

  const getQuestionStatus = (index: number) => {
    if (index === currentQuestionIndex) return 'current';
    if (answers[index]) return 'answered';
    return 'unattempted';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">Please sign in to access exam mode.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate exam results when completed
  const calculateResults = () => {
    const results = {
      totalQuestions: questions.length,
      answeredQuestions: Object.keys(answers).length,
      correctAnswers: 0,
      subjectBreakdown: {} as Record<string, { correct: number; total: number; questions: { question: Question; userAnswer: string; correct: boolean }[] }>,
      timeSpent: EXAM_DURATION - timeRemaining
    };

    // Calculate correct answers and subject breakdown
    questions.forEach((question, index) => {
      const userAnswer = answers[index];
      const isCorrect = userAnswer === question.correctAnswer;
      
      if (isCorrect) results.correctAnswers++;

      if (!results.subjectBreakdown[question.subjectId]) {
        results.subjectBreakdown[question.subjectId] = { correct: 0, total: 0, questions: [] };
      }
      
      results.subjectBreakdown[question.subjectId].total++;
      if (isCorrect) results.subjectBreakdown[question.subjectId].correct++;
      
      results.subjectBreakdown[question.subjectId].questions.push({
        question,
        userAnswer: userAnswer || '',
        correct: isCorrect
      });
    });

    const score = Math.round((results.correctAnswers / results.totalQuestions) * 400);
    const percentage = Math.round((results.correctAnswers / results.totalQuestions) * 100);

    return { ...results, score, percentage };
  };

  const examResults = examCompleted ? calculateResults() : null;

  // Exam Results Page
  if (examCompleted && examResults) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Results Header */}
          <Card className="mb-8">
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-500 to-green-500 flex items-center justify-center">
                  <span className="text-3xl font-bold text-white">{examResults.percentage}%</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Exam Completed!</h2>
                <p className="text-xl text-gray-600">Your JAMB Mock Examination Results</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-blue-600">{examResults.score}</div>
                  <div className="text-sm text-gray-500">Total Score (out of 400)</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600">{examResults.correctAnswers}</div>
                  <div className="text-sm text-gray-500">Correct Answers</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-orange-600">{examResults.answeredQuestions}</div>
                  <div className="text-sm text-gray-500">Questions Attempted</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-600">{Math.floor(examResults.timeSpent / 60)}min</div>
                  <div className="text-sm text-gray-500">Time Spent</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Subject Breakdown */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {Object.entries(examResults.subjectBreakdown).map(([subjectId, breakdown]) => {
              const subjectName = JAMB_SUBJECTS.find(s => s.id === subjectId)?.name || subjectId;
              const percentage = Math.round((breakdown.correct / breakdown.total) * 100);
              
              return (
                <Card key={subjectId}>
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-lg mb-4">{subjectName}</h3>
                    <div className="text-center mb-4">
                      <div className="text-2xl font-bold text-blue-600">{percentage}%</div>
                      <div className="text-sm text-gray-500">{breakdown.correct}/{breakdown.total} correct</div>
                    </div>
                    <Progress value={percentage} className="w-full" />
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Detailed Review */}
          <Card>
            <CardHeader>
              <CardTitle>Question Review</CardTitle>
              <p className="text-gray-600">Review your answers and see the correct solutions</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Object.entries(examResults.subjectBreakdown).map(([subjectId, breakdown]) => {
                  const subjectName = JAMB_SUBJECTS.find(s => s.id === subjectId)?.name || subjectId;
                  
                  return (
                    <div key={subjectId}>
                      <h3 className="text-xl font-semibold mb-4 text-blue-600">{subjectName}</h3>
                      <div className="space-y-4">
                        {breakdown.questions.map((item, index) => (
                          <div key={item.question.id} className={`p-4 rounded-lg border-2 ${
                            item.correct ? 'bg-green-50 border-green-200' : 
                            item.userAnswer ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'
                          }`}>
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-medium text-sm">Question {index + 1}</span>
                              <span className={`px-2 py-1 rounded text-xs font-medium ${
                                item.correct ? 'bg-green-100 text-green-800' :
                                item.userAnswer ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'
                              }`}>
                                {item.correct ? 'Correct' : item.userAnswer ? 'Incorrect' : 'Not Attempted'}
                              </span>
                            </div>
                            
                            <div className="mb-3">
                              <p className="text-gray-900 font-medium">{item.question.questionText}</p>
                            </div>

                            <div className="grid gap-2 mb-3">
                              {item.question.options.map((option) => (
                                <div key={option.label} className={`p-2 rounded border ${
                                  option.label === item.question.correctAnswer ? 'bg-green-100 border-green-300' :
                                  option.label === item.userAnswer && item.userAnswer !== item.question.correctAnswer ? 'bg-red-100 border-red-300' :
                                  'bg-white border-gray-200'
                                }`}>
                                  <span className="font-medium">{option.label}.</span> {option.text}
                                  {option.label === item.question.correctAnswer && (
                                    <span className="ml-2 text-green-600 font-medium">✓ Correct Answer</span>
                                  )}
                                  {option.label === item.userAnswer && item.userAnswer !== item.question.correctAnswer && (
                                    <span className="ml-2 text-red-600 font-medium">✗ Your Answer</span>
                                  )}
                                </div>
                              ))}
                            </div>

                            <div className="bg-blue-50 p-3 rounded border border-blue-200">
                              <p className="text-sm text-blue-900"><strong>Explanation:</strong> {item.question.explanation}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
              
              <div className="mt-8 text-center space-y-4">
                <Button 
                  onClick={() => {
                    setExamCompleted(false);
                    setExamStarted(false);
                    setAnswers({});
                    setCurrentQuestionIndex(0);
                    setSelectedAnswer("");
                    setFlaggedQuestions(new Set());
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                  data-testid="button-retake-exam"
                >
                  Take Another Practice Exam
                </Button>
                <div>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.href = '/analytics'}
                    data-testid="button-view-analytics"
                  >
                    View Detailed Analytics
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!examStarted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">JAMB UTME Mock Examination</CardTitle>
              <p className="text-gray-600">
                This is a complete simulation of the JAMB UTME examination format
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Exam Structure:</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Total Questions: 180</li>
                    <li>• Duration: 2 hours</li>
                    <li>• Use of English: 60 questions</li>
                    <li>• Mathematics: 40 questions</li>
                    <li>• Physics: 40 questions</li>
                    <li>• Chemistry: 40 questions</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-3">Instructions:</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Select only one answer per question</li>
                    <li>• You can flag questions for review</li>
                    <li>• Time will auto-submit when it expires</li>
                    <li>• Your progress is automatically saved</li>
                  </ul>
                </div>
              </div>
              
              <div className="text-center">
                <Button
                  onClick={handleStartExam}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-4"
                  data-testid="button-start-exam"
                >
                  Start Exam
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Exam Header */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold mb-2 text-white">JAMB UTME Mock Examination</h2>
                <p className="text-gray-300">180 Questions • 4 Subjects • Total Score: 400 marks</p>
              </div>
              <div className="text-right">
                <Timer 
                  time={formattedTime}
                  isRunning={isRunning}
                  variant={timeRemaining < 600 ? "danger" : "default"}
                />
                <div className="text-sm text-gray-400">Time Remaining</div>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Progress</span>
                <span>{currentQuestionIndex + 1}/180 Questions</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Question Navigation Panel */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-800 border-gray-700 sticky top-24">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4 text-white">Question Navigation</h3>
                <div className="space-y-4">
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Use of English (1-60)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 60}, (_, i) => (
                        <button
                          key={i}
                          onClick={() => handleNavigateToQuestion(i)}
                          className={`w-6 h-6 text-xs rounded font-medium ${
                            getQuestionStatus(i) === 'current' ? 'bg-blue-600 text-white' :
                            getQuestionStatus(i) === 'answered' ? 'bg-green-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}
                          data-testid={`nav-question-${i + 1}`}
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Mathematics (61-100)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 60}
                          onClick={() => handleNavigateToQuestion(i + 60)}
                          className={`w-6 h-6 text-xs rounded font-medium ${
                            getQuestionStatus(i + 60) === 'current' ? 'bg-blue-600 text-white' :
                            getQuestionStatus(i + 60) === 'answered' ? 'bg-green-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}
                          data-testid={`nav-question-${i + 61}`}
                        >
                          {i + 61}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-gray-400 mb-2">Physics (101-140)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 100}
                          onClick={() => handleNavigateToQuestion(i + 100)}
                          className={`w-6 h-6 text-xs rounded font-medium ${
                            getQuestionStatus(i + 100) === 'current' ? 'bg-blue-600 text-white' :
                            getQuestionStatus(i + 100) === 'answered' ? 'bg-green-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}
                          data-testid={`nav-question-${i + 101}`}
                        >
                          {i + 101}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-gray-400 mb-2">Chemistry (141-180)</div>
                    <div className="grid grid-cols-10 gap-1">
                      {Array.from({length: 40}, (_, i) => (
                        <button
                          key={i + 140}
                          onClick={() => handleNavigateToQuestion(i + 140)}
                          className={`w-6 h-6 text-xs rounded font-medium ${
                            getQuestionStatus(i + 140) === 'current' ? 'bg-blue-600 text-white' :
                            getQuestionStatus(i + 140) === 'answered' ? 'bg-green-600 text-white' :
                            'bg-gray-600 text-gray-300'
                          }`}
                          data-testid={`nav-question-${i + 141}`}
                        >
                          {i + 141}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 space-y-2 text-sm">
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-blue-600 rounded mr-2"></div>
                    <span className="text-gray-300">Current</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-green-600 rounded mr-2"></div>
                    <span className="text-gray-300">Answered</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-4 h-4 bg-gray-600 rounded mr-2"></div>
                    <span className="text-gray-300">Not Attempted</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Question Area */}
          <div className="lg:col-span-3">
            {currentQuestion && (
              <Card className="bg-gray-800 border-gray-700 mb-6">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <Badge className="bg-blue-600 text-white">{currentSubject}</Badge>
                      <span className="text-gray-400">
                        Question {currentQuestionIndex + 1} of {questions.length}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold mb-4 text-white">
                      Question {currentQuestionIndex + 1}
                    </h3>
                  </div>

                  <div className="text-lg text-gray-100 mb-8 leading-relaxed">
                    {currentQuestion.questionText}
                  </div>

                  <RadioGroup
                    value={selectedAnswer}
                    onValueChange={handleAnswerChange}
                    className="space-y-4"
                  >
                    {currentQuestion.options.map((option) => (
                      <div key={option.label} className="flex items-center space-x-2">
                        <RadioGroupItem value={option.label} id={option.label} />
                        <Label
                          htmlFor={option.label}
                          className="flex-1 p-4 border-2 border-gray-600 rounded-lg hover:border-blue-500 cursor-pointer transition-colors"
                          data-testid={`exam-option-${option.label}`}
                        >
                          <span className="font-medium text-white mr-2">{option.label}.</span>
                          <span className="text-gray-200">{option.text}</span>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>

                  <div className="mt-8 flex justify-between">
                    <Button
                      variant="outline"
                      onClick={handlePreviousQuestion}
                      disabled={currentQuestionIndex === 0}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      data-testid="button-exam-previous"
                    >
                      <ChevronLeft className="h-4 w-4 mr-2" />
                      Previous
                    </Button>
                    
                    <div className="flex space-x-3">
                      <Button
                        variant="outline"
                        onClick={toggleFlag}
                        className={`border-gray-600 hover:bg-gray-700 ${
                          flaggedQuestions.has(currentQuestionIndex) ? 'bg-yellow-600 text-white' : 'text-gray-300'
                        }`}
                        data-testid="button-flag-question"
                      >
                        <Flag className="h-4 w-4 mr-2" />
                        Flag for Review
                      </Button>
                      <Button
                        onClick={handleNextQuestion}
                        disabled={currentQuestionIndex === questions.length - 1}
                        className="bg-blue-600 hover:bg-blue-700"
                        data-testid="button-exam-next"
                      >
                        Save & Next
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Exam Controls */}
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="flex space-x-4">
                    <Button
                      onClick={handleSubmitExam}
                      className="bg-red-600 hover:bg-red-700"
                      data-testid="button-submit-exam"
                    >
                      Submit Exam
                    </Button>
                    <Button
                      variant="outline"
                      onClick={isRunning ? pause : start}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                      data-testid="button-pause-resume"
                    >
                      {isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                      {isRunning ? 'Pause' : 'Resume'}
                    </Button>
                  </div>
                  <div className="text-gray-400 text-sm flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    Auto-save enabled • Answered: {Object.keys(answers).length}/{questions.length}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
