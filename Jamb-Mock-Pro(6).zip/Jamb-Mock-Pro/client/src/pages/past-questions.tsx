import { Calendar, Download, Eye, BookOpen } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function PastQuestions() {
  const pastQuestions = [
    {
      year: 2024,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Current Standard",
    },
    {
      year: 2023,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Current Standard",
    },
    {
      year: 2022,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Current Standard",
    },
    {
      year: 2021,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Current Standard",
    },
    {
      year: 2020,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Similar Standard",
    },
    {
      year: 2019,
      subjects: ["English", "Mathematics", "Physics", "Chemistry", "Biology"],
      questions: 180,
      available: true,
      difficulty: "Similar Standard",
    },
  ];

  const subjectStats = [
    { subject: "Use of English", totalQuestions: 1080, years: 6 },
    { subject: "Mathematics", totalQuestions: 1080, years: 6 },
    { subject: "Physics", totalQuestions: 1080, years: 6 },
    { subject: "Chemistry", totalQuestions: 1080, years: 6 },
    { subject: "Biology", totalQuestions: 1080, years: 6 },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">JAMB Past Questions</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Practice with authentic JAMB questions from previous years to familiarize yourself with exam patterns and difficulty levels
        </p>
      </div>

      {/* Statistics Overview */}
      <div className="grid md:grid-cols-5 gap-4 mb-12">
        {subjectStats.map((stat) => (
          <Card key={stat.subject} className="text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-600">{stat.totalQuestions}</div>
              <div className="text-sm text-gray-600">{stat.subject}</div>
              <div className="text-xs text-gray-500">{stat.years} years available</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Past Questions by Year */}
      <div className="space-y-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Questions by Year</h2>
        
        <div className="grid gap-6">
          {pastQuestions.map((yearData) => (
            <Card key={yearData.year} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Calendar className="h-5 w-5 text-blue-600" />
                      <span>JAMB {yearData.year}</span>
                    </CardTitle>
                    <CardDescription>
                      {yearData.questions} questions across {yearData.subjects.length} subjects
                    </CardDescription>
                  </div>
                  <Badge variant={yearData.year >= 2021 ? "default" : "secondary"}>
                    {yearData.difficulty}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {yearData.subjects.map((subject) => (
                        <Badge key={subject} variant="outline">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">
                      Practice with real questions from {yearData.year} JAMB examination
                    </p>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Start Practice
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Study Benefits */}
      <div className="mt-16 bg-green-50 rounded-lg p-8">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6 text-center">
          Why Practice Past Questions?
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Exam Familiarity</h3>
            <p className="text-gray-700 text-sm">
              Get comfortable with JAMB's question style, format, and timing expectations.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Calendar className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Pattern Recognition</h3>
            <p className="text-gray-700 text-sm">
              Identify recurring topics and question types that appear frequently in JAMB.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Download className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Confidence Building</h3>
            <p className="text-gray-700 text-sm">
              Build confidence by successfully solving questions from actual JAMB examinations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}