import { useState } from "react";
import { Search, ChevronDown, ChevronRight, HelpCircle, BookOpen, Users, Settings } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const categories = [
    {
      id: "getting-started",
      name: "Getting Started",
      icon: BookOpen,
      description: "Learn the basics of using JAMB Mock Pro",
      articles: 8,
    },
    {
      id: "account",
      name: "Account & Settings",
      icon: Settings,
      description: "Manage your profile and preferences",
      articles: 6,
    },
    {
      id: "practice",
      name: "Practice & Exams",
      icon: HelpCircle,
      description: "How to use practice modes and take mock exams",
      articles: 12,
    },
    {
      id: "technical",
      name: "Technical Support",
      icon: Users,
      description: "Troubleshooting and technical issues",
      articles: 5,
    },
  ];

  const faqs = [
    {
      question: "How do I create an account on JAMB Mock Pro?",
      answer: "You can create an account by clicking the 'Sign In' button and choosing either Google sign-in or email registration. If using email, you'll need to verify your email address before accessing all features.",
    },
    {
      question: "What's the difference between Practice Mode and Mock Exam Mode?",
      answer: "Practice Mode allows you to study at your own pace with immediate feedback and detailed explanations. Mock Exam Mode simulates the actual JAMB experience with time limits and no immediate feedback during the exam.",
    },
    {
      question: "Can I practice specific subjects only?",
      answer: "Yes! Use the Subject Practice feature to focus on individual subjects like Mathematics, English, Physics, Chemistry, or Biology. This helps you strengthen weak areas.",
    },
    {
      question: "How accurate are the practice questions compared to real JAMB?",
      answer: "Our questions are carefully crafted by education experts to match JAMB standards. We also include actual past questions from previous JAMB examinations for authentic practice.",
    },
    {
      question: "Can I track my progress and performance?",
      answer: "Absolutely! Your Performance Analytics dashboard shows detailed statistics about your scores, improvement trends, subject strengths, and areas needing more attention.",
    },
    {
      question: "Is JAMB Mock Pro free to use?",
      answer: "Yes, JAMB Mock Pro offers free access to practice questions and basic features. Some advanced analytics and premium content may require a subscription in the future.",
    },
    {
      question: "What devices can I use to access JAMB Mock Pro?",
      answer: "JAMB Mock Pro works on all devices - computers, tablets, and smartphones. The interface is responsive and optimized for all screen sizes.",
    },
    {
      question: "How do I reset my password?",
      answer: "Click 'Sign In', then 'Forgot Password', and enter your email address. You'll receive a password reset link in your email inbox.",
    },
  ];

  const filteredFaqs = faqs.filter(faq => 
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Help Center</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Find answers to common questions and get help with using JAMB Mock Pro
        </p>
      </div>

      {/* Search */}
      <div className="max-w-2xl mx-auto mb-12">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            type="text"
            placeholder="Search help articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12 text-lg"
            data-testid="search-input"
          />
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Need Quick Help?</CardTitle>
            <CardDescription className="text-blue-700">
              Contact our support team for personalized assistance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link href="/contact-us">Contact Support</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-green-900">New to JAMB Mock Pro?</CardTitle>
            <CardDescription className="text-green-700">
              Learn how to get started with our platform
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-100">
              Getting Started Guide
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Help Categories */}
        <div className="lg:col-span-1">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Browse by Category</h2>
          <div className="space-y-4">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Card key={category.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <IconComponent className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{category.name}</h3>
                        <p className="text-sm text-gray-600">{category.articles} articles</p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-gray-400" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <Card key={index} className="hover:shadow-sm transition-shadow">
                <CardContent className="p-0">
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                    className="w-full p-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                    data-testid={`faq-question-${index}`}
                  >
                    <h3 className="font-semibold text-gray-900 pr-4">{faq.question}</h3>
                    {expandedFaq === index ? (
                      <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />
                    ) : (
                      <ChevronRight className="h-5 w-5 text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                  
                  {expandedFaq === index && (
                    <div className="px-6 pb-6 border-t border-gray-100">
                      <p className="text-gray-700 pt-4" data-testid={`faq-answer-${index}`}>
                        {faq.answer}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredFaqs.length === 0 && searchQuery && (
            <div className="text-center py-12">
              <p className="text-gray-500">No results found for "{searchQuery}"</p>
              <Button
                variant="ghost"
                onClick={() => setSearchQuery("")}
                className="mt-2"
              >
                Clear search
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Still Need Help */}
      <div className="mt-16 bg-gray-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Still Need Help?</h2>
        <p className="text-gray-600 mb-6">
          Can't find what you're looking for? Our support team is here to help you succeed.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild>
            <Link href="/contact-us">Contact Support</Link>
          </Button>
          <Button variant="outline">
            Request New Feature
          </Button>
        </div>
      </div>
    </div>
  );
}