import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Copy, CreditCard, Building2, CheckCircle, Loader } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/hooks/use-user';
import { trackEvent } from '@/lib/analytics';
import { HCaptchaWrapper } from '@/components/hcaptcha-wrapper';

// Paystack Popup interface
declare global {
  interface Window {
    PaystackPop: any;
  }
}

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentComplete: () => void;
}

export function PaymentModal({ isOpen, onClose, onPaymentComplete }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'paystack' | 'bank_transfer'>('paystack');
  const [transactionRef, setTransactionRef] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [showCaptcha, setShowCaptcha] = useState(false);
  const { toast } = useToast();
  const { user, verifyPayment, isVerifyingPayment } = useUser();

  const bankDetails = {
    bankName: 'GTBank',
    accountName: 'JAMB Mock Pro',
    accountNumber: '0123456789',
    amount: '₦1,000'
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: `${label} copied to clipboard`,
    });
  };

  const handleCaptchaVerify = (token: string) => {
    setCaptchaVerified(true);
    setShowCaptcha(false);
    trackEvent('payment_captcha_verified', 'security', 'payment_protection');
  };

  const handleCaptchaExpire = () => {
    setCaptchaVerified(false);
    toast({
      title: 'Verification Expired',
      description: 'Please complete the verification again.',
      variant: 'destructive',
    });
  };

  const handlePaystackPayment = () => {
    if (!user?.email) {
      toast({
        title: 'Email Required',
        description: 'Please sign in to continue with payment',
        variant: 'destructive',
      });
      return;
    }

    // Require captcha verification for payments
    if (!captchaVerified) {
      setShowCaptcha(true);
      toast({
        title: 'Security Verification Required',
        description: 'Please complete the verification below to proceed with payment.',
        variant: 'destructive',
      });
      return;
    }

    trackEvent('payment_initiated', 'payment', 'paystack', 1000);
    setIsProcessing(true);

    // Initialize Paystack payment
    const paystackHandler = window.PaystackPop.setup({
      key: import.meta.env.VITE_PAYSTACK_PUBLIC_KEY,
      email: user.email,
      amount: 100000, // ₦1,000 in kobo (multiply by 100)
      currency: 'NGN',
      callback: async function(response: any) {
        try {
          // Verify payment on our backend
          await verifyPayment({ 
            transactionRef: response.reference, 
            amount: 1000
          });
          trackEvent('payment_successful', 'payment', 'paystack', 1000);
          onPaymentComplete();
          onClose();
          toast({
            title: 'Payment Successful!',
            description: 'Your exam credit has been added.',
          });
        } catch (error) {
          trackEvent('payment_verification_failed', 'payment', 'paystack');
          toast({
            title: 'Payment Verification Failed',
            description: 'Please contact support if this persists.',
            variant: 'destructive',
          });
        } finally {
          setIsProcessing(false);
        }
      },
      onClose: function() {
        trackEvent('payment_cancelled', 'payment', 'paystack');
        setIsProcessing(false);
        toast({
          title: 'Payment Cancelled',
          description: 'You can try again when ready.',
        });
      }
    });

    paystackHandler.openIframe();
  };

  const handleBankTransferConfirmation = async () => {
    if (!transactionRef.trim()) {
      toast({
        title: 'Missing Transaction Reference',
        description: 'Please enter your bank transfer reference number',
        variant: 'destructive',
      });
      return;
    }

    // Require captcha verification for bank transfer verification too
    if (!captchaVerified) {
      setShowCaptcha(true);
      toast({
        title: 'Security Verification Required',
        description: 'Please complete the verification below to verify your payment.',
        variant: 'destructive',
      });
      return;
    }

    try {
      await verifyPayment({ 
        transactionRef: transactionRef.trim(), 
        amount: 1000
      });
      onPaymentComplete();
      onClose();
      setTransactionRef('');
    } catch (error) {
      // Error handling is done in the useUser hook
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Unlock Exam Mode</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">₦1,000</div>
            <p className="text-sm text-muted-foreground">Pay once to take one mock exam</p>
          </div>

          <div className="grid gap-3">
            <Button
              variant={paymentMethod === 'paystack' ? 'default' : 'outline'}
              className="flex items-center gap-2 h-auto p-4"
              onClick={() => setPaymentMethod('paystack')}
            >
              <CreditCard className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">Pay with Card</div>
                <div className="text-sm opacity-75">Instant payment via Paystack</div>
              </div>
            </Button>
            
            <Button
              variant={paymentMethod === 'bank_transfer' ? 'default' : 'outline'}
              className="flex items-center gap-2 h-auto p-4"
              onClick={() => setPaymentMethod('bank_transfer')}
            >
              <Building2 className="w-5 h-5" />
              <div className="text-left">
                <div className="font-medium">Bank Transfer</div>
                <div className="text-xs opacity-75">Most popular in Nigeria</div>
              </div>
            </Button>


          </div>

          {paymentMethod === 'paystack' && (
            <div className="text-center space-y-4">
              {showCaptcha && (
                <div className="space-y-3">
                  <p className="text-sm text-gray-600 text-center">
                    Security verification required for payment:
                  </p>
                  <HCaptchaWrapper
                    onVerify={handleCaptchaVerify}
                    onExpire={handleCaptchaExpire}
                    size="compact"
                    theme="light"
                  />
                </div>
              )}
              
              <Button
                onClick={handlePaystackPayment}
                disabled={isProcessing}
                className="w-full bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                {isProcessing ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin mr-2" />
                    Processing Payment...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Pay ₦1,000 with Paystack
                  </>
                )}
              </Button>
              <p className="text-xs text-gray-500 mt-2">
                Secure payment powered by Paystack
              </p>
            </div>
          )}

          {paymentMethod === 'bank_transfer' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Bank Transfer Details</CardTitle>
                <CardDescription>Transfer exactly ₦1,000 to the account below</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Bank Name:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{bankDetails.bankName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(bankDetails.bankName, 'Bank name')}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Account Name:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{bankDetails.accountName}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(bankDetails.accountName, 'Account name')}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Account Number:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-mono">{bankDetails.accountNumber}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(bankDetails.accountNumber, 'Account number')}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Amount:</span>
                    <Badge variant="secondary" className="font-mono">
                      {bankDetails.amount}
                    </Badge>
                  </div>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
                    <div className="text-xs text-yellow-800 dark:text-yellow-200">
                      <strong>Important:</strong> After transfer, enter your transaction reference and click verify. 
                      Payment will be verified instantly and your exam credits will be added immediately.
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Transaction Reference Number
                    </label>
                    <input
                      type="text"
                      value={transactionRef}
                      onChange={(e) => setTransactionRef(e.target.value)}
                      placeholder="Enter your bank transfer reference"
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>

                  {showCaptcha && (
                    <div className="space-y-3">
                      <p className="text-sm text-gray-600 text-center">
                        Security verification required for payment verification:
                      </p>
                      <HCaptchaWrapper
                        onVerify={handleCaptchaVerify}
                        onExpire={handleCaptchaExpire}
                        size="compact"
                        theme="light"
                      />
                    </div>
                  )}

                  <Button
                    onClick={handleBankTransferConfirmation}
                    disabled={isVerifyingPayment || !transactionRef.trim()}
                    className="w-full"
                  >
                    {isVerifyingPayment ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin mr-2" />
                        Verifying Payment...
                      </>
                    ) : (
                      'Verify Payment & Add Credits'
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="text-center">
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}