import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { JAMB_SUBJECTS } from "@/data/subjects";
import { 
  TrendingUp, 
  BookOpen, 
  Target, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Languages,
  Calculator,
  Atom,
  FlaskConical,
  Building2,
  Globe,
  ScrollText,
  Award,
  Calendar,
  BarChart3,
  Users,
  Lightbulb
} from "lucide-react";

const subjectIcons = {
  "language": Languages,
  "calculator": Calculator,
  "atom": Atom,
  "flask": FlaskConical,
  "university": Building2,
  "trending-up": TrendingUp,
  "book": BookOpen,
  "globe": Globe,
  "scroll": ScrollText,
};

// Real analytics data from user's actual performance
const generateRealAnalytics = (userId: string, userProgress: any[], examAttempts: any[], practiceAttempts: any[]) => {
  // Calculate real overall score from exam attempts
  const totalExamScore = examAttempts.reduce((sum, exam) => sum + (exam.totalScore || 0), 0);
  const averageExamScore = examAttempts.length > 0 ? Math.round(totalExamScore / examAttempts.length) : 0;
  
  // Calculate practice sessions this month
  const thisMonth = new Date();
  const startOfMonth = new Date(thisMonth.getFullYear(), thisMonth.getMonth(), 1);
  const practiceThisMonth = practiceAttempts.filter(attempt => 
    new Date(attempt.attemptedAt) >= startOfMonth
  ).length;
  
  // Calculate study streak (consecutive days with activity)
  const sortedAttempts = [...practiceAttempts, ...examAttempts]
    .sort((a, b) => new Date(b.attemptedAt || b.startedAt).getTime() - new Date(a.attemptedAt || a.startedAt).getTime());
  
  let currentStreak = 0;
  let bestStreak = 0;
  let streakCount = 0;
  let lastDate = null;
  
  for (const attempt of sortedAttempts) {
    const attemptDate = new Date(attempt.attemptedAt || attempt.startedAt);
    const dateString = attemptDate.toDateString();
    
    if (lastDate !== dateString) {
      if (lastDate === null || 
          (new Date(lastDate).getTime() - attemptDate.getTime()) / (1000 * 60 * 60 * 24) === 1) {
        streakCount++;
        if (currentStreak === 0) currentStreak = streakCount;
      } else {
        bestStreak = Math.max(bestStreak, streakCount);
        streakCount = 1;
        currentStreak = 0;
      }
      lastDate = dateString;
    }
  }
  bestStreak = Math.max(bestStreak, streakCount);
  if (currentStreak === 0) currentStreak = streakCount;

  return {
    overallScore: {
      current: averageExamScore,
      total: 400,
      get percentage() { return (this.current / this.total) * 100; }
    },
    practiceSessions: {
      thisMonth: practiceThisMonth,
      get improvement() { 
        // Calculate improvement from first vs last exam
        if (examAttempts.length < 2) return 0;
        const firstExam = examAttempts[examAttempts.length - 1];
        const lastExam = examAttempts[0];
        return Math.round(((lastExam.totalScore || 0) - (firstExam.totalScore || 0)) / 4); // Convert to percentage points
      }
    },
    studyStreak: {
      current: currentStreak,
      best: bestStreak
    },
    subjectPerformance: JAMB_SUBJECTS.slice(0, 6).map(subject => {
      const subjectProgress = userProgress.find(p => p.subjectId === subject.id);
      const subjectPractice = practiceAttempts.filter(p => p.subjectId === subject.id);
      
      return {
        id: subject.id,
        subject: subject.name,
        icon: subjectIcons[subject.icon as keyof typeof subjectIcons] || BookOpen,
        score: subjectProgress?.averageScore || 0,
        improvement: 0, // Could calculate from trend analysis
        practiceCount: subjectProgress?.totalAttempts || 0,
        averageTime: 60, // Default since we don't track time per question yet
        color: subject.id === 'use-of-english' ? 'text-blue-600' :
               subject.id === 'mathematics' ? 'text-green-600' :
               subject.id === 'physics' ? 'text-purple-600' :
               subject.id === 'chemistry' ? 'text-red-600' :
               subject.id === 'biology' ? 'text-green-500' :
               'text-orange-600'
      };
    }),
    recentActivity: [...examAttempts, ...practiceAttempts]
      .sort((a, b) => new Date(b.attemptedAt || b.startedAt).getTime() - new Date(a.attemptedAt || a.startedAt).getTime())
      .slice(0, 4)
      .map(attempt => {
        const isExam = 'totalScore' in attempt;
        const date = new Date(attempt.attemptedAt || attempt.startedAt);
        const timeAgo = formatTimeAgo(date);
        
        return {
          type: isExam ? "exam" : "practice",
          subject: isExam ? "Mock Exam" : attempt.subjectId || "Practice",
          score: isExam ? `${attempt.totalScore}/400` : (attempt.isCorrect ? "Correct" : "Incorrect"),
          time: timeAgo,
          icon: isExam ? Clock : CheckCircle,
          iconColor: isExam ? "text-blue-600" : (attempt.isCorrect ? "text-green-600" : "text-red-600"),
          bgColor: isExam ? "bg-blue-100" : (attempt.isCorrect ? "bg-green-100" : "bg-red-100")
        };
      }),
    weeklyProgress: generateWeeklyProgress(practiceAttempts, examAttempts),
    examHistory: examAttempts.slice(0, 3).map(exam => ({
      date: new Date(exam.startedAt).toISOString().split('T')[0],
      score: exam.totalScore || 0,
      subjects: ["English", "Math", "Science"], // Could be extracted from exam data
      duration: exam.completedAt && exam.startedAt ? 
        formatDuration(new Date(exam.completedAt).getTime() - new Date(exam.startedAt).getTime()) : 
        "2h 0m"
    }))
  };
};

// Helper functions for real data processing
function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  if (diffHours < 1) return "Just now";
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  return date.toLocaleDateString();
}

function formatDuration(ms: number): string {
  const hours = Math.floor(ms / (1000 * 60 * 60));
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
}

function generateWeeklyProgress(practiceAttempts: any[], examAttempts: any[]) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const weekData = days.map((day, index) => {
    // Calculate average score for this day of week from recent attempts
    const dayAttempts = [...practiceAttempts, ...examAttempts].filter(attempt => {
      const attemptDate = new Date(attempt.attemptedAt || attempt.startedAt);
      return attemptDate.getDay() === (index + 1) % 7; // Monday = 1, Sunday = 0
    });
    
    const avgScore = dayAttempts.length > 0 ? 
      dayAttempts.reduce((sum, attempt) => {
        return sum + (attempt.isCorrect ? 100 : (attempt.totalScore || 0) / 4);
      }, 0) / dayAttempts.length : 0;
    
    return { day, score: Math.round(avgScore) };
  });
  
  return weekData;
}

interface PerformanceAnalyticsProps {
  onStartPractice?: () => void;
  onStartExam?: () => void;
}

export function PerformanceAnalytics({ onStartPractice, onStartExam }: PerformanceAnalyticsProps) {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      // Fetch real analytics data from backend
      const fetchAnalyticsData = async () => {
        try {
          setLoading(true);
          
          // Fetch user's actual data from backend
          const [userProgressRes, examAttemptsRes, practiceAttemptsRes] = await Promise.all([
            fetch(`/api/user-progress/user/${user.uid}`),
            fetch(`/api/exam-attempts/user/${user.uid}`),
            fetch(`/api/practice-attempts/user/${user.uid}`)
          ]);
          
          const userProgress = userProgressRes.ok ? await userProgressRes.json() : [];
          const examAttempts = examAttemptsRes.ok ? await examAttemptsRes.json() : [];
          const practiceAttempts = practiceAttemptsRes.ok ? await practiceAttemptsRes.json() : [];
          
          // Generate real analytics from actual data
          const analytics = generateRealAnalytics(user.uid, userProgress, examAttempts, practiceAttempts);
          setAnalytics(analytics);
        } catch (error) {
          console.error("Error fetching analytics data:", error);
          // Fallback to empty data structure
          setAnalytics({
            overallScore: { current: 0, total: 400, percentage: 0 },
            practiceSessions: { thisMonth: 0, improvement: 0 },
            studyStreak: { current: 0, best: 0 },
            subjectPerformance: [],
            recentActivity: [],
            weeklyProgress: [],
            examHistory: []
          });
        } finally {
          setLoading(false);
        }
      };
      
      fetchAnalyticsData();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">Please sign in to view your performance analytics.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading || !analytics) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-300 rounded w-1/3"></div>
            <div className="grid lg:grid-cols-3 gap-8">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-32 bg-gray-300 rounded"></div>
              ))}
            </div>
            <div className="grid lg:grid-cols-2 gap-8">
              {[1, 2].map(i => (
                <div key={i} className="h-64 bg-gray-300 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const getPerformanceLevel = (score: number) => {
    if (score >= 80) return { level: "Excellent", color: "text-green-600", bgColor: "bg-green-50" };
    if (score >= 70) return { level: "Good", color: "text-blue-600", bgColor: "bg-blue-50" };
    if (score >= 60) return { level: "Average", color: "text-yellow-600", bgColor: "bg-yellow-50" };
    return { level: "Needs Improvement", color: "text-red-600", bgColor: "bg-red-50" };
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Performance Analytics</h1>
          <p className="text-lg text-gray-600">Track your progress and identify areas for improvement</p>
        </div>

        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="subjects">Subjects</TabsTrigger>
            <TabsTrigger value="exams">Exam History</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Overview Cards */}
            <div className="grid lg:grid-cols-3 gap-8">
              <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-900">Overall Score</h3>
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {analytics.overallScore.current}/{analytics.overallScore.total}
                  </div>
                  <div className="text-sm text-gray-600 mb-4">
                    Last exam: {Math.round(analytics.overallScore.percentage)}%
                  </div>
                  <Progress value={analytics.overallScore.percentage} className="h-2" />
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-900">Practice Sessions</h3>
                    <BookOpen className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    {analytics.practiceSessions.thisMonth}
                  </div>
                  <div className="text-sm text-gray-600 mb-4">This month</div>
                  <div className="text-sm text-green-600 font-medium">
                    <TrendingUp className="h-3 w-3 inline mr-1" />
                    +{analytics.practiceSessions.improvement}% from last month
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-100">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-gray-900">Study Streak</h3>
                    <Target className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="text-3xl font-bold text-purple-600 mb-2">
                    {analytics.studyStreak.current} days
                  </div>
                  <div className="text-sm text-gray-600 mb-4">
                    Best: {analytics.studyStreak.best} days
                  </div>
                  <div className="text-sm text-purple-600 font-medium">
                    Keep it up! 🎉
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Weekly Progress Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Weekly Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between h-40 space-x-2">
                  {analytics.weeklyProgress.map((day: any, index: number) => (
                    <div key={index} className="flex flex-col items-center flex-1">
                      <div 
                        className="bg-blue-500 rounded-t-sm w-full transition-all hover:bg-blue-600"
                        style={{ height: `${(day.score / 100) * 120}px` }}
                      ></div>
                      <div className="text-xs text-gray-600 mt-2">{day.day}</div>
                      <div className="text-xs font-medium">{day.score}%</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics.recentActivity.map((activity: any, index: number) => {
                    const IconComponent = activity.icon;
                    return (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`w-8 h-8 ${activity.bgColor} rounded-full flex items-center justify-center`}>
                          <IconComponent className={`h-4 w-4 ${activity.iconColor}`} />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900">
                            {activity.type === 'practice' && `Completed ${activity.subject} Practice`}
                            {activity.type === 'exam' && `Started ${activity.subject}`}
                            {activity.type === 'streak' && `Achieved ${activity.subject}`}
                          </div>
                          <div className="text-xs text-gray-500">
                            {activity.time}
                            {activity.score && ` • Score: ${activity.score}`}
                            {activity.duration && ` • Duration: ${activity.duration}`}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subjects" className="space-y-8">
            {/* Subject Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Subject Performance Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {analytics.subjectPerformance.map((subject: any, index: number) => {
                    const IconComponent = subject.icon;
                    const performance = getPerformanceLevel(subject.score);
                    
                    return (
                      <Card key={index} className={`${performance.bgColor} border-gray-200`}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <IconComponent className={`h-5 w-5 ${subject.color}`} />
                              <h4 className="font-semibold">{subject.subject}</h4>
                            </div>
                            <Badge className={performance.color}>{performance.level}</Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Current Score</span>
                              <span className="font-semibold">{subject.score}%</span>
                            </div>
                            <Progress value={subject.score} className="h-2" />
                            
                            <div className="grid grid-cols-2 gap-4 mt-3 text-xs text-gray-600">
                              <div>
                                <div className="font-medium">Practice Sessions</div>
                                <div>{subject.practiceCount}</div>
                              </div>
                              <div>
                                <div className="font-medium">Avg. Time/Question</div>
                                <div>{subject.averageTime}s</div>
                              </div>
                            </div>
                            
                            {subject.improvement !== 0 && (
                              <div className={`text-xs font-medium ${
                                subject.improvement > 0 ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {subject.improvement > 0 ? '+' : ''}{subject.improvement}% this week
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="exams" className="space-y-8">
            {/* Exam History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Mock Exam History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics.examHistory.map((exam: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <div className="font-semibold">Mock Exam #{analytics.examHistory.length - index}</div>
                        <div className="text-sm text-gray-600">{exam.date}</div>
                        <div className="text-xs text-gray-500">
                          Subjects: {exam.subjects.join(", ")}
                        </div>
                      </div>
                      <div className="text-right space-y-1">
                        <div className="text-lg font-bold text-blue-600">{exam.score}/400</div>
                        <div className="text-sm text-gray-600">{exam.duration}</div>
                        <Badge variant={exam.score >= 250 ? "default" : exam.score >= 200 ? "secondary" : "destructive"}>
                          {Math.round((exam.score / 400) * 100)}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-8">
            {/* Study Recommendations */}
            <div className="grid md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-red-600">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    Areas to Focus On
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analytics.subjectPerformance
                    .filter((subject: any) => subject.score < 70)
                    .map((subject: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                        <span className="text-sm font-medium text-red-900">{subject.subject}</span>
                        <Badge variant="destructive">{subject.score}% - Needs Improvement</Badge>
                      </div>
                    ))}
                  {analytics.subjectPerformance.filter((subject: any) => subject.score < 70).length === 0 && (
                    <div className="text-center text-gray-500 py-4">
                      <Award className="h-8 w-8 mx-auto mb-2 text-green-500" />
                      Great job! All subjects are performing well.
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-green-600">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Strong Areas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {analytics.subjectPerformance
                    .filter((subject: any) => subject.score >= 80)
                    .map((subject: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <span className="text-sm font-medium text-green-900">{subject.subject}</span>
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{subject.score}% - Excellent</Badge>
                      </div>
                    ))}
                </CardContent>
              </Card>
            </div>

            {/* Personalized Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Lightbulb className="h-5 w-5 mr-2" />
                  Personalized Study Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">This Week's Goals:</h4>
                    <ul className="space-y-2 text-sm text-gray-700">
                      <li className="flex items-center">
                        <Target className="h-3 w-3 mr-2 text-blue-500" />
                        Complete 5 practice sessions
                      </li>
                      <li className="flex items-center">
                        <Target className="h-3 w-3 mr-2 text-blue-500" />
                        Take 1 full mock exam
                      </li>
                      <li className="flex items-center">
                        <Target className="h-3 w-3 mr-2 text-blue-500" />
                        Improve weakest subject by 5%
                      </li>
                    </ul>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Quick Actions:</h4>
                    <div className="space-y-2">
                      <Button 
                        onClick={onStartPractice}
                        className="w-full bg-green-600 hover:bg-green-700"
                        size="sm"
                      >
                        <BookOpen className="h-4 w-4 mr-2" />
                        Start Practice Session
                      </Button>
                      <Button 
                        onClick={onStartExam}
                        variant="outline"
                        className="w-full"
                        size="sm"
                      >
                        <Clock className="h-4 w-4 mr-2" />
                        Take Mock Exam
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
