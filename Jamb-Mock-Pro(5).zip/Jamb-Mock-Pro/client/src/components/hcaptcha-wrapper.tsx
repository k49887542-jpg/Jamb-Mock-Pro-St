import { useEffect, useRef } from 'react';
import HCaptcha from '@hcaptcha/react-hcaptcha';

interface HCaptchaWrapperProps {
  onVerify: (token: string) => void;
  onExpire?: () => void;
  onError?: (err: any) => void;
  size?: 'normal' | 'compact';
  theme?: 'light' | 'dark';
}

export function HCaptchaWrapper({ 
  onVerify, 
  onExpire, 
  onError, 
  size = 'normal',
  theme = 'light' 
}: HCaptchaWrapperProps) {
  const captchaRef = useRef<HCaptcha>(null);
  const siteKey = import.meta.env.VITE_HCAPTCHA_SITE_KEY;

  // Reset captcha when component unmounts or on error
  const resetCaptcha = () => {
    if (captchaRef.current) {
      captchaRef.current.resetCaptcha();
    }
  };

  const handleExpire = () => {
    resetCaptcha();
    if (onExpire) {
      onExpire();
    }
  };

  const handleError = (err: any) => {
    console.error('hCaptcha error:', err);
    resetCaptcha();
    if (onError) {
      onError(err);
    }
  };

  if (!siteKey) {
    console.warn('hCaptcha site key not found. Please add VITE_HCAPTCHA_SITE_KEY to your environment variables.');
    return (
      <div className="p-4 border border-blue-200 bg-blue-50 rounded-md">
        <p className="text-sm text-blue-800 mb-2 font-medium">
          Security verification temporarily disabled
        </p>
        <p className="text-xs text-blue-700">
          Deploy your app first to get a cleaner domain for hCaptcha setup, or add 'localhost' to your hCaptcha domains for testing.
        </p>
      </div>
    );
  }

  return (
    <div className="flex justify-center">
      <HCaptcha
        ref={captchaRef}
        sitekey={siteKey}
        onVerify={onVerify}
        onExpire={handleExpire}
        onError={handleError}
        size={size}
        theme={theme}
      />
    </div>
  );
}