import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Clock, BookOpen } from 'lucide-react';
import { JAMB_SUBJECTS } from '@/data/subjects';

interface ExamSubjectSelectionProps {
  onStartExam: (selectedSubjects: string[]) => void;
  onBack: () => void;
}

export function ExamSubjectSelection({ onStartExam, onBack }: ExamSubjectSelectionProps) {
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(['use-of-english']); // English is mandatory

  const handleSubjectToggle = (subjectId: string) => {
    if (subjectId === 'use-of-english') return; // English is mandatory

    setSelectedSubjects(prev => {
      if (prev.includes(subjectId)) {
        return prev.filter(id => id !== subjectId);
      } else if (prev.length < 4) {
        return [...prev, subjectId];
      } else {
        return prev;
      }
    });
  };

  const availableSubjects = JAMB_SUBJECTS.filter(subject => subject.id !== 'use-of-english');
  const remainingSlots = 4 - selectedSubjects.length;

  const canStartExam = selectedSubjects.length === 4;

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader className="text-center">
          <CardTitle>Select Your Exam Subjects</CardTitle>
          <CardDescription>
            Choose exactly 4 subjects for your JAMB mock examination. 
            Use of English is mandatory for all candidates.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Exam Information */}
          <div className="grid grid-cols-3 gap-4 p-4 bg-muted rounded-lg">
            <div className="text-center">
              <Clock className="w-6 h-6 mx-auto mb-1 text-primary" />
              <div className="text-sm font-medium">3 Hours</div>
              <div className="text-xs text-muted-foreground">Total Time</div>
            </div>
            <div className="text-center">
              <BookOpen className="w-6 h-6 mx-auto mb-1 text-primary" />
              <div className="text-sm font-medium">180 Questions</div>
              <div className="text-xs text-muted-foreground">45 per subject</div>
            </div>
            <div className="text-center">
              <div className="w-6 h-6 mx-auto mb-1 text-primary font-bold text-lg">₦</div>
              <div className="text-sm font-medium">₦1,000</div>
              <div className="text-xs text-muted-foreground">Per attempt</div>
            </div>
          </div>

          {/* Mandatory Subject */}
          <div>
            <h3 className="font-semibold mb-3">Mandatory Subject</h3>
            <div className="grid gap-3">
              <div className="flex items-center space-x-3 p-3 border rounded-lg bg-primary/5">
                <Checkbox
                  checked={true}
                  disabled={true}
                  data-testid="checkbox-use-of-english"
                />
                <div className="flex-1">
                  <div className="font-medium">Use of English</div>
                  <div className="text-sm text-muted-foreground">Compulsory for all candidates</div>
                </div>
                <Badge variant="secondary">Mandatory</Badge>
              </div>
            </div>
          </div>

          {/* Optional Subjects */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold">Choose 3 More Subjects</h3>
              <Badge variant={remainingSlots === 0 ? 'default' : 'outline'}>
                {remainingSlots} slots remaining
              </Badge>
            </div>

            <div className="grid gap-3">
              {availableSubjects.map((subject) => {
                const isSelected = selectedSubjects.includes(subject.id);
                const isDisabled = !isSelected && selectedSubjects.length >= 4;

                return (
                  <div
                    key={subject.id}
                    className={`flex items-center space-x-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                      isSelected 
                        ? 'bg-primary/10 border-primary' 
                        : isDisabled 
                          ? 'opacity-50 cursor-not-allowed'
                          : 'hover:bg-muted'
                    }`}
                    onClick={() => !isDisabled && handleSubjectToggle(subject.id)}
                  >
                    <Checkbox
                      checked={isSelected}
                      disabled={isDisabled}
                      data-testid={`checkbox-${subject.id}`}
                    />
                    <div className="flex-1">
                      <div className="font-medium">{subject.name}</div>
                      <div className="text-sm text-muted-foreground">{subject.description}</div>
                    </div>
                    <Badge variant="outline">{subject.code}</Badge>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Subjects Summary */}
          {selectedSubjects.length > 0 && (
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-medium mb-2">Selected Subjects ({selectedSubjects.length}/4):</h4>
              <div className="flex flex-wrap gap-2">
                {selectedSubjects.map((subjectId) => {
                  const subject = JAMB_SUBJECTS.find(s => s.id === subjectId);
                  return (
                    <Badge key={subjectId} variant="default">
                      {subject?.code} - {subject?.name}
                    </Badge>
                  );
                })}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-between pt-4">
            <Button variant="outline" onClick={onBack}>
              Back
            </Button>
            <Button 
              onClick={() => canStartExam && onStartExam(selectedSubjects)}
              disabled={!canStartExam}
              className="flex items-center gap-2"
              data-testid="button-start-exam"
            >
              Start Mock Exam
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}