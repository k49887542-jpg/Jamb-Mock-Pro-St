export default function UniversityGuide() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">University Guide</h1>
      <p className="text-gray-600">Coming soon - Complete guide to Nigerian universities and admission requirements.</p>
    </div>
  );
}