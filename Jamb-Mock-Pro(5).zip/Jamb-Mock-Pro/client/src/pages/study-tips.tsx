import { Clock, Brain, Target, BookOpen, TrendingUp, Users } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function StudyTips() {
  const studyStrategies = [
    {
      icon: Clock,
      title: "Time Management",
      tips: [
        "Create a realistic daily study schedule and stick to it",
        "Use the Pomodoro Technique: 25 minutes focused study, 5-minute break",
        "Allocate more time to your weaker subjects",
        "Set specific time limits for each subject during practice sessions"
      ]
    },
    {
      icon: Brain,
      title: "Effective Learning Techniques",
      tips: [
        "Active recall: Test yourself without looking at notes",
        "Spaced repetition: Review topics at increasing intervals",
        "Create mind maps to visualize connections between topics",
        "Teach concepts to someone else to reinforce understanding"
      ]
    },
    {
      icon: Target,
      title: "Goal Setting & Tracking",
      tips: [
        "Set SMART goals (Specific, Measurable, Achievable, Relevant, Time-bound)",
        "Track your progress with our Performance Analytics",
        "Set weekly targets for practice questions completed",
        "Celebrate small wins to maintain motivation"
      ]
    },
    {
      icon: BookOpen,
      title: "Subject-Specific Strategies",
      tips: [
        "English: Read newspapers daily to improve comprehension",
        "Mathematics: Practice calculations without calculator regularly",
        "Sciences: Focus on understanding concepts, not memorization",
        "Use past questions to identify frequently tested topics"
      ]
    }
  ];

  const examTips = [
    {
      title: "Pre-Exam Preparation",
      description: "Final weeks before your JAMB examination",
      points: [
        "Review your weakest topics identified through practice tests",
        "Take full mock exams under timed conditions",
        "Prepare all required documents and exam materials",
        "Get adequate sleep and maintain a healthy routine"
      ]
    },
    {
      title: "Exam Day Strategy",
      description: "Maximize your performance during the actual exam",
      points: [
        "Arrive early to avoid stress and settle in comfortably",
        "Read all instructions carefully before starting",
        "Answer easy questions first to build confidence",
        "Manage your time: don't spend too long on difficult questions"
      ]
    },
    {
      title: "Question Answering Techniques",
      description: "Smart approaches to tackling JAMB questions",
      points: [
        "Eliminate obviously wrong options first",
        "Look for keywords and context clues in questions",
        "For calculations, estimate answers to verify your work",
        "Trust your first instinct if you're unsure between two options"
      ]
    }
  ];

  const subjectTips = {
    "Use of English": [
      "Read diverse materials: novels, newspapers, academic texts",
      "Practice comprehension passages daily",
      "Learn common prefixes, suffixes, and root words",
      "Focus on grammar rules and sentence structure"
    ],
    "Mathematics": [
      "Master basic arithmetic and mental calculations",
      "Practice with formula sheets until memorized",
      "Work through problems step-by-step methodically",
      "Review and understand your calculation errors"
    ],
    "Physics": [
      "Understand fundamental concepts before memorizing formulas",
      "Practice drawing and interpreting graphs and diagrams",
      "Connect physics principles to real-world applications",
      "Focus on units and dimensional analysis"
    ],
    "Chemistry": [
      "Memorize the periodic table and common chemical reactions",
      "Practice balancing chemical equations regularly",
      "Understand the relationship between organic and inorganic chemistry",
      "Focus on practical applications and laboratory procedures"
    ],
    "Biology": [
      "Create detailed diagrams of biological processes",
      "Use mnemonics to remember classification systems",
      "Focus on human anatomy and plant biology",
      "Connect biological concepts to health and environment"
    ]
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Study Tips & Strategies</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Proven strategies and expert advice to help you study more effectively and achieve excellent JAMB scores
        </p>
      </div>

      {/* General Study Strategies */}
      <section className="mb-16">
        <h2 className="text-3xl font-semibold text-gray-900 mb-8 text-center">General Study Strategies</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {studyStrategies.map((strategy, index) => {
            const IconComponent = strategy.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <IconComponent className="h-6 w-6 text-blue-600" />
                    </div>
                    <CardTitle>{strategy.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {strategy.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="flex items-start space-x-2">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700 text-sm">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Exam-Specific Tips */}
      <section className="mb-16">
        <h2 className="text-3xl font-semibold text-gray-900 mb-8 text-center">Exam Success Strategies</h2>
        <div className="space-y-6">
          {examTips.map((section, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-xl">{section.title}</CardTitle>
                <CardDescription>{section.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {section.points.map((point, pointIndex) => (
                    <div key={pointIndex} className="flex items-start space-x-2">
                      <TrendingUp className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{point}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Subject-Specific Tips */}
      <section className="mb-16">
        <h2 className="text-3xl font-semibold text-gray-900 mb-8 text-center">Subject-Specific Study Tips</h2>
        <div className="space-y-6">
          {Object.entries(subjectTips).map(([subject, tips]) => (
            <Card key={subject} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-xl">{subject}</CardTitle>
                <CardDescription>
                  Targeted strategies for mastering {subject.toLowerCase()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {tips.map((tip, tipIndex) => (
                    <div key={tipIndex} className="flex items-start space-x-2">
                      <BookOpen className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{tip}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Motivation & Mindset */}
      <section>
        <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-8">
          <h2 className="text-3xl font-semibold text-gray-900 mb-6 text-center">
            Maintain the Right Mindset
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Target className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Stay Focused</h3>
              <p className="text-gray-700 text-sm">
                Keep your end goal in mind. Every study session brings you closer to your dream university.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Brain className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Think Positive</h3>
              <p className="text-gray-700 text-sm">
                Believe in yourself. With consistent effort and smart studying, you can achieve excellent scores.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Get Support</h3>
              <p className="text-gray-700 text-sm">
                Join study groups, seek help when needed, and lean on family and friends for encouragement.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}