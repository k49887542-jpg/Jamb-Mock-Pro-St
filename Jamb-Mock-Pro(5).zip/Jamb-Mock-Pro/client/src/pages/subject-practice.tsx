import { BookOpen, Calculator, Atom, FlaskConical, Microscope } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function SubjectPractice() {
  const subjects = [
    {
      id: "english",
      name: "Use of English",
      icon: BookOpen,
      description: "Master grammar, comprehension, and lexis & structure",
      questionsCount: 150,
      color: "bg-blue-500",
    },
    {
      id: "mathematics",
      name: "Mathematics",
      icon: Calculator,
      description: "Algebra, geometry, statistics, and calculus",
      questionsCount: 200,
      color: "bg-green-500",
    },
    {
      id: "physics",
      name: "Physics", 
      icon: Atom,
      description: "Mechanics, electricity, waves, and modern physics",
      questionsCount: 180,
      color: "bg-purple-500",
    },
    {
      id: "chemistry",
      name: "Chemistry",
      icon: FlaskConical,
      description: "Organic, inorganic, and physical chemistry",
      questionsCount: 175,
      color: "bg-orange-500",
    },
    {
      id: "biology",
      name: "Biology",
      icon: Microscope,
      description: "Ecology, genetics, anatomy, and plant biology",
      questionsCount: 190,
      color: "bg-teal-500",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Subject Practice</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Focus on specific subjects to strengthen your weak areas and master JAMB topics
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject) => {
          const IconComponent = subject.icon;
          return (
            <Card key={subject.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className={`w-12 h-12 rounded-lg ${subject.color} flex items-center justify-center mb-4`}>
                  <IconComponent className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-xl">{subject.name}</CardTitle>
                <CardDescription>{subject.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-gray-600">
                    <span className="font-semibold">{subject.questionsCount}</span> practice questions available
                  </div>
                  
                  <div className="space-y-2">
                    <Button asChild className="w-full">
                      <Link href={`/practice?subject=${subject.id}`}>
                        Start Practice
                      </Link>
                    </Button>
                    <Button variant="outline" asChild className="w-full">
                      <Link href={`/exam?subject=${subject.id}`}>
                        Take Subject Exam
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-16 bg-blue-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-semibold text-gray-900 mb-4">Study Tips for Subject Practice</h2>
        <div className="grid md:grid-cols-3 gap-6 mt-8 text-left">
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Focus on Weak Areas</h3>
            <p className="text-gray-700 text-sm">
              Use your analytics to identify subjects where you score lower and spend more time practicing them.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Review Explanations</h3>
            <p className="text-gray-700 text-sm">
              Always read the detailed explanations for both correct and incorrect answers to understand concepts better.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Track Your Progress</h3>
            <p className="text-gray-700 text-sm">
              Monitor your improvement over time and adjust your study plan based on your performance trends.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}