import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { 
  TrendingUp, 
  BookOpen, 
  Target, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Languages,
  Calculator,
  Atom,
  FlaskConical
} from "lucide-react";

// Mock analytics data - in a real app, this would come from your backend
const mockAnalytics = {
  overallScore: {
    current: 285,
    total: 400,
    percentage: 71.25
  },
  practiceSessions: {
    thisMonth: 42,
    improvement: 15
  },
  studyStreak: {
    current: 7,
    best: 14
  },
  subjectPerformance: [
    { subject: "Use of English", icon: Languages, score: 85, color: "text-blue-600" },
    { subject: "Mathematics", icon: Calculator, score: 72, color: "text-green-600" },
    { subject: "Physics", icon: Atom, score: 68, color: "text-purple-600" },
    { subject: "Chemistry", icon: FlaskConical, score: 58, color: "text-red-600" },
  ],
  recentActivity: [
    {
      type: "practice",
      subject: "Mathematics",
      score: "78/100",
      time: "2 hours ago",
      icon: CheckCircle,
      iconColor: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      type: "exam",
      subject: "Mock Exam",
      duration: "2h 5m",
      time: "Yesterday",
      icon: Clock,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      type: "streak",
      subject: "7-day streak",
      time: "2 days ago",
      icon: Target,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ]
};

export default function Analytics() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Sign In Required</h2>
            <p className="text-gray-600 mb-6">Please sign in to view your performance analytics.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Your Performance Analytics</h1>
          <p className="text-lg text-gray-600">Track your progress and identify areas for improvement</p>
        </div>

        {/* Overview Cards */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Overall Score</h3>
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-green-600 mb-2">
                {mockAnalytics.overallScore.current}/{mockAnalytics.overallScore.total}
              </div>
              <div className="text-sm text-gray-600 mb-4">
                Last exam: {mockAnalytics.overallScore.percentage}%
              </div>
              <Progress value={mockAnalytics.overallScore.percentage} className="h-2" />
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Practice Sessions</h3>
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {mockAnalytics.practiceSessions.thisMonth}
              </div>
              <div className="text-sm text-gray-600 mb-4">This month</div>
              <div className="text-sm text-green-600 font-medium">
                <TrendingUp className="h-3 w-3 inline mr-1" />
                +{mockAnalytics.practiceSessions.improvement}% from last month
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Study Streak</h3>
                <Target className="h-6 w-6 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {mockAnalytics.studyStreak.current} days
              </div>
              <div className="text-sm text-gray-600 mb-4">Current streak</div>
              <div className="text-sm text-purple-600 font-medium">
                Keep it up! 🎉
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Subject Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Subject Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {mockAnalytics.subjectPerformance.map((subject, index) => {
                  const IconComponent = subject.icon;
                  return (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <IconComponent className={`h-5 w-5 ${subject.color}`} />
                        <span className="font-medium">{subject.subject}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-32">
                          <Progress 
                            value={subject.score} 
                            className={`h-2 ${
                              subject.score >= 80 ? '[&>div]:bg-green-500' :
                              subject.score >= 65 ? '[&>div]:bg-yellow-500' :
                              '[&>div]:bg-red-500'
                            }`}
                          />
                        </div>
                        <span className="text-sm font-medium text-gray-700 w-8">
                          {subject.score}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockAnalytics.recentActivity.map((activity, index) => {
                  const IconComponent = activity.icon;
                  return (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-8 h-8 ${activity.bgColor} rounded-full flex items-center justify-center`}>
                        <IconComponent className={`h-4 w-4 ${activity.iconColor}`} />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-900">
                          {activity.type === 'practice' && `Completed ${activity.subject} Practice`}
                          {activity.type === 'exam' && `Started ${activity.subject}`}
                          {activity.type === 'streak' && `Achieved ${activity.subject}`}
                        </div>
                        <div className="text-xs text-gray-500">
                          {activity.time}
                          {activity.score && ` • Score: ${activity.score}`}
                          {activity.duration && ` • Duration: ${activity.duration}`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Study Recommendations */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-blue-600" />
              <span>Study Recommendations</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-medium text-gray-900">Areas to Focus On:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <span className="text-sm font-medium text-red-900">Chemistry</span>
                    <Badge variant="destructive">58% - Needs Improvement</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <span className="text-sm font-medium text-yellow-900">Physics</span>
                    <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">68% - Below Average</Badge>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium text-gray-900">Strong Areas:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm font-medium text-green-900">Use of English</span>
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100">85% - Excellent</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm font-medium text-blue-900">Mathematics</span>
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">72% - Good</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
