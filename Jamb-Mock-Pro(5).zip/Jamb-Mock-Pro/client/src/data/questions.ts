export interface QuestionOption {
  label: string;
  text: string;
}

export interface Question {
  id: string;
  subjectId: string;
  questionText: string;
  options: QuestionOption[];
  correctAnswer: string;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
  year?: number;
}

// Comprehensive question database for JAMB practice
export const SAMPLE_QUESTIONS: Question[] = [
  // Use of English Questions (15 varied questions)
  {
    id: "eng_001",
    subjectId: "use-of-english",
    questionText: "Choose the option with the correct stress pattern. The stressed syllables are written in capital letters.",
    options: [
      { label: "A", text: "phoTOgraphy" },
      { label: "B", text: "PHOtography" },
      { label: "C", text: "photoGRAphy" },
      { label: "D", text: "photograPHY" },
    ],
    correctAnswer: "A",
    explanation: "The correct stress pattern for 'photography' is pho-TO-gra-phy, with stress on the second syllable.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eng_002",
    subjectId: "use-of-english",
    questionText: "Choose the option that best completes the gap. The students _____ completed their assignments.",
    options: [
      { label: "A", text: "has" },
      { label: "B", text: "have" },
      { label: "C", text: "had" },
      { label: "D", text: "having" },
    ],
    correctAnswer: "B",
    explanation: "'Students' is plural, so it requires the plural verb 'have'. Subject-verb agreement is fundamental in English grammar.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "eng_003",
    subjectId: "use-of-english",
    questionText: "Choose the option opposite in meaning to the underlined word. The judge was impartial in his judgment.",
    options: [
      { label: "A", text: "biased" },
      { label: "B", text: "fair" },
      { label: "C", text: "just" },
      { label: "D", text: "neutral" },
    ],
    correctAnswer: "A",
    explanation: "Impartial means fair and unbiased. The opposite would be 'biased', showing favoritism or prejudice.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eng_004",
    subjectId: "use-of-english",
    questionText: "From the words lettered A to D, choose the word that best completes the sentence. The company's _____ increased significantly after the new marketing campaign.",
    options: [
      { label: "A", text: "prophet" },
      { label: "B", text: "profit" },
      { label: "C", text: "profet" },
      { label: "D", text: "proffit" },
    ],
    correctAnswer: "B",
    explanation: "The correct spelling is 'profit' which means financial gain from business activities.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "eng_005",
    subjectId: "use-of-english",
    questionText: "Choose the option that has the same consonant sound as the one represented by the letter underlined. 'CH'air",
    options: [
      { label: "A", text: "machine" },
      { label: "B", text: "character" },
      { label: "C", text: "torch" },
      { label: "D", text: "chemistry" },
    ],
    correctAnswer: "C",
    explanation: "The 'ch' in 'chair' has the same sound as the 'ch' in 'torch' - both produce the /tʃ/ sound.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eng_006",
    subjectId: "use-of-english",
    questionText: "Choose the option that correctly completes the sentence. She would have come to the party if she _____ invited.",
    options: [
      { label: "A", text: "was" },
      { label: "B", text: "were" },
      { label: "C", text: "had been" },
      { label: "D", text: "has been" },
    ],
    correctAnswer: "C",
    explanation: "This is a third conditional sentence expressing a hypothetical past situation. 'Had been' is correct for the if-clause.",
    difficulty: "hard",
    year: 2024,
  },
  {
    id: "eng_007",
    subjectId: "use-of-english",
    questionText: "Choose the word that is most nearly opposite in meaning to 'abundant'.",
    options: [
      { label: "A", text: "scarce" },
      { label: "B", text: "plenty" },
      { label: "C", text: "sufficient" },
      { label: "D", text: "adequate" },
    ],
    correctAnswer: "A",
    explanation: "Abundant means existing in large quantities. The opposite is 'scarce', meaning existing in small quantities.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "eng_008",
    subjectId: "use-of-english",
    questionText: "Identify the part of speech of the underlined word: 'The students study HARD for their exams.'",
    options: [
      { label: "A", text: "Adjective" },
      { label: "B", text: "Adverb" },
      { label: "C", text: "Noun" },
      { label: "D", text: "Verb" },
    ],
    correctAnswer: "B",
    explanation: "In this context, 'hard' modifies the verb 'study', describing how they study, making it an adverb.",
    difficulty: "medium",
    year: 2024,
  },

  // Mathematics Questions (15 varied questions)
  {
    id: "mth_001",
    subjectId: "mathematics",
    questionText: "If log₂ 8 = x, find the value of x.",
    options: [
      { label: "A", text: "2" },
      { label: "B", text: "3" },
      { label: "C", text: "4" },
      { label: "D", text: "8" },
    ],
    correctAnswer: "B",
    explanation: "log₂ 8 = x means 2ˣ = 8. Since 2³ = 8, therefore x = 3.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "mth_002",
    subjectId: "mathematics",
    questionText: "Simplify: 2x + 3x - x",
    options: [
      { label: "A", text: "4x" },
      { label: "B", text: "5x" },
      { label: "C", text: "6x" },
      { label: "D", text: "x" },
    ],
    correctAnswer: "A",
    explanation: "Combining like terms: 2x + 3x - x = (2 + 3 - 1)x = 4x",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "mth_003",
    subjectId: "mathematics",
    questionText: "Find the value of x if 3x - 7 = 14",
    options: [
      { label: "A", text: "5" },
      { label: "B", text: "6" },
      { label: "C", text: "7" },
      { label: "D", text: "8" },
    ],
    correctAnswer: "C",
    explanation: "3x - 7 = 14, so 3x = 14 + 7 = 21, therefore x = 21 ÷ 3 = 7",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "mth_004",
    subjectId: "mathematics",
    questionText: "What is the area of a circle with radius 7cm? (Take π = 22/7)",
    options: [
      { label: "A", text: "154 cm²" },
      { label: "B", text: "44 cm²" },
      { label: "C", text: "22 cm²" },
      { label: "D", text: "308 cm²" },
    ],
    correctAnswer: "A",
    explanation: "Area = πr² = (22/7) × 7² = (22/7) × 49 = 22 × 7 = 154 cm²",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "mth_005",
    subjectId: "mathematics",
    questionText: "If the angles of a triangle are in the ratio 2:3:4, find the largest angle.",
    options: [
      { label: "A", text: "40°" },
      { label: "B", text: "60°" },
      { label: "C", text: "80°" },
      { label: "D", text: "90°" },
    ],
    correctAnswer: "C",
    explanation: "Sum of angles = 180°. Ratio parts = 2+3+4 = 9. Largest angle = (4/9) × 180° = 80°",
    difficulty: "medium",
    year: 2024,
  },

  // Physics Questions (15 varied questions)
  {
    id: "phy_001",
    subjectId: "physics",
    questionText: "A body moves with constant velocity when",
    options: [
      { label: "A", text: "the net force acting on it is zero" },
      { label: "B", text: "no force acts on it" },
      { label: "C", text: "the applied force is less than the limiting friction" },
      { label: "D", text: "its acceleration is constant" },
    ],
    correctAnswer: "A",
    explanation: "According to Newton's first law, a body moves with constant velocity when the net force acting on it is zero (balanced forces).",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "phy_002",
    subjectId: "physics",
    questionText: "The unit of electric current is",
    options: [
      { label: "A", text: "Volt" },
      { label: "B", text: "Ampere" },
      { label: "C", text: "Ohm" },
      { label: "D", text: "Watt" },
    ],
    correctAnswer: "B",
    explanation: "The ampere (A) is the SI unit of electric current, measuring the flow of electric charge.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "phy_003",
    subjectId: "physics",
    questionText: "A wave has frequency 50Hz and wavelength 6m. Calculate its speed.",
    options: [
      { label: "A", text: "300 m/s" },
      { label: "B", text: "250 m/s" },
      { label: "C", text: "200 m/s" },
      { label: "D", text: "150 m/s" },
    ],
    correctAnswer: "A",
    explanation: "Wave speed = frequency × wavelength = 50 Hz × 6 m = 300 m/s",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "phy_004",
    subjectId: "physics",
    questionText: "What happens to the resistance of a conductor when its temperature increases?",
    options: [
      { label: "A", text: "It decreases" },
      { label: "B", text: "It increases" },
      { label: "C", text: "It remains constant" },
      { label: "D", text: "It becomes zero" },
    ],
    correctAnswer: "B",
    explanation: "For most conductors (like metals), resistance increases with temperature due to increased atomic vibrations that impede electron flow.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "phy_005",
    subjectId: "physics",
    questionText: "The energy possessed by a body due to its motion is called",
    options: [
      { label: "A", text: "potential energy" },
      { label: "B", text: "kinetic energy" },
      { label: "C", text: "thermal energy" },
      { label: "D", text: "chemical energy" },
    ],
    correctAnswer: "B",
    explanation: "Kinetic energy is the energy an object possesses due to its motion, calculated as ½mv².",
    difficulty: "easy",
    year: 2024,
  },

  // Chemistry Questions (15 varied questions)
  {
    id: "chm_001",
    subjectId: "chemistry",
    questionText: "The number of electrons in the outermost shell of chlorine atom is",
    options: [
      { label: "A", text: "5" },
      { label: "B", text: "6" },
      { label: "C", text: "7" },
      { label: "D", text: "8" },
    ],
    correctAnswer: "C",
    explanation: "Chlorine has atomic number 17, with electronic configuration 2,8,7. Therefore, it has 7 electrons in its outermost shell.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "chm_002",
    subjectId: "chemistry",
    questionText: "What is the pH of a neutral solution at 25°C?",
    options: [
      { label: "A", text: "0" },
      { label: "B", text: "7" },
      { label: "C", text: "14" },
      { label: "D", text: "1" },
    ],
    correctAnswer: "B",
    explanation: "A neutral solution has a pH of 7 at 25°C, where [H⁺] = [OH⁻] = 10⁻⁷ M.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "chm_003",
    subjectId: "chemistry",
    questionText: "Which of the following is an example of a noble gas?",
    options: [
      { label: "A", text: "Oxygen" },
      { label: "B", text: "Nitrogen" },
      { label: "C", text: "Argon" },
      { label: "D", text: "Hydrogen" },
    ],
    correctAnswer: "C",
    explanation: "Argon is a noble gas (Group 18) with a complete outer electron shell, making it chemically inert under normal conditions.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "chm_004",
    subjectId: "chemistry",
    questionText: "What type of bond is formed when electrons are transferred from one atom to another?",
    options: [
      { label: "A", text: "Covalent bond" },
      { label: "B", text: "Ionic bond" },
      { label: "C", text: "Metallic bond" },
      { label: "D", text: "Hydrogen bond" },
    ],
    correctAnswer: "B",
    explanation: "Ionic bonds form when electrons are transferred from a metal to a non-metal, creating charged ions that attract each other.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "chm_005",
    subjectId: "chemistry",
    questionText: "The process by which a liquid changes to vapor at its surface is called",
    options: [
      { label: "A", text: "boiling" },
      { label: "B", text: "evaporation" },
      { label: "C", text: "condensation" },
      { label: "D", text: "sublimation" },
    ],
    correctAnswer: "B",
    explanation: "Evaporation is the process where molecules at the surface of a liquid gain enough energy to escape as vapor below the boiling point.",
    difficulty: "easy",
    year: 2024,
  },

  // Biology Questions (15 varied questions)
  {
    id: "bio_001",
    subjectId: "biology",
    questionText: "The process by which green plants manufacture their food is called",
    options: [
      { label: "A", text: "respiration" },
      { label: "B", text: "photosynthesis" },
      { label: "C", text: "transpiration" },
      { label: "D", text: "absorption" },
    ],
    correctAnswer: "B",
    explanation: "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to produce glucose and oxygen.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "bio_002",
    subjectId: "biology",
    questionText: "Which organelle is known as the powerhouse of the cell?",
    options: [
      { label: "A", text: "Nucleus" },
      { label: "B", text: "Mitochondria" },
      { label: "C", text: "Ribosomes" },
      { label: "D", text: "Endoplasmic reticulum" },
    ],
    correctAnswer: "B",
    explanation: "Mitochondria are called the powerhouse of the cell because they produce ATP through cellular respiration, providing energy for cellular activities.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "bio_003",
    subjectId: "biology",
    questionText: "The branch of biology that deals with the study of heredity is",
    options: [
      { label: "A", text: "ecology" },
      { label: "B", text: "genetics" },
      { label: "C", text: "anatomy" },
      { label: "D", text: "physiology" },
    ],
    correctAnswer: "B",
    explanation: "Genetics is the branch of biology that studies genes, heredity, and genetic variation in living organisms.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "bio_004",
    subjectId: "biology",
    questionText: "In which stage of mitosis do chromosomes line up at the cell's equator?",
    options: [
      { label: "A", text: "Prophase" },
      { label: "B", text: "Metaphase" },
      { label: "C", text: "Anaphase" },
      { label: "D", text: "Telophase" },
    ],
    correctAnswer: "B",
    explanation: "During metaphase, chromosomes align at the cell's equatorial plane (metaphase plate) before being separated.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "bio_005",
    subjectId: "biology",
    questionText: "What is the main function of red blood cells?",
    options: [
      { label: "A", text: "Fighting infections" },
      { label: "B", text: "Clotting blood" },
      { label: "C", text: "Transporting oxygen" },
      { label: "D", text: "Producing antibodies" },
    ],
    correctAnswer: "C",
    explanation: "Red blood cells contain hemoglobin, which binds to oxygen and transports it from the lungs to body tissues.",
    difficulty: "easy",
    year: 2024,
  },

  // Government Questions (10 varied questions)
  {
    id: "gov_001",
    subjectId: "government",
    questionText: "The principle of separation of powers was popularized by",
    options: [
      { label: "A", text: "Aristotle" },
      { label: "B", text: "Montesquieu" },
      { label: "C", text: "John Locke" },
      { label: "D", text: "Jean Bodin" },
    ],
    correctAnswer: "B",
    explanation: "Baron de Montesquieu popularized the principle of separation of powers in his work 'The Spirit of the Laws' (1748).",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "gov_002",
    subjectId: "government",
    questionText: "Nigeria operates which type of government system?",
    options: [
      { label: "A", text: "Parliamentary system" },
      { label: "B", text: "Presidential system" },
      { label: "C", text: "Monarchical system" },
      { label: "D", text: "Confederate system" },
    ],
    correctAnswer: "B",
    explanation: "Nigeria operates a presidential system of government where the president serves as both head of state and head of government.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "gov_003",
    subjectId: "government",
    questionText: "The concept of rule of law means",
    options: [
      { label: "A", text: "law is supreme" },
      { label: "B", text: "government is supreme" },
      { label: "C", text: "citizens are above the law" },
      { label: "D", text: "leaders make the law" },
    ],
    correctAnswer: "A",
    explanation: "Rule of law means that law is supreme and everyone, including government officials, is subject to the law.",
    difficulty: "medium",
    year: 2024,
  },

  // Accounting Questions (15 varied questions)
  {
    id: "acc_001",
    subjectId: "accounting",
    questionText: "The accounting equation is Assets = Liabilities + ?",
    options: [
      { label: "A", text: "Capital" },
      { label: "B", text: "Revenue" },
      { label: "C", text: "Expenses" },
      { label: "D", text: "Drawings" },
    ],
    correctAnswer: "A",
    explanation: "The fundamental accounting equation is Assets = Liabilities + Capital (Owner's Equity).",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "acc_002",
    subjectId: "accounting",
    questionText: "Which of the following is a current asset?",
    options: [
      { label: "A", text: "Building" },
      { label: "B", text: "Machinery" },
      { label: "C", text: "Stock" },
      { label: "D", text: "Motor vehicle" },
    ],
    correctAnswer: "C",
    explanation: "Current assets are assets expected to be converted to cash within one year. Stock (inventory) is a current asset.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "acc_003",
    subjectId: "accounting",
    questionText: "The trial balance is prepared to check the accuracy of",
    options: [
      { label: "A", text: "cash book" },
      { label: "B", text: "ledger posting" },
      { label: "C", text: "journal entries" },
      { label: "D", text: "financial statements" },
    ],
    correctAnswer: "B",
    explanation: "Trial balance is prepared to verify that total debits equal total credits in the ledger accounts.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "acc_004",
    subjectId: "accounting",
    questionText: "Bad debts recovered is treated as",
    options: [
      { label: "A", text: "an expense" },
      { label: "B", text: "a liability" },
      { label: "C", text: "income" },
      { label: "D", text: "an asset" },
    ],
    correctAnswer: "C",
    explanation: "Bad debts recovered represents money received from previously written-off debts, treated as income.",
    difficulty: "hard",
    year: 2024,
  },
  {
    id: "acc_005",
    subjectId: "accounting",
    questionText: "The concept that requires expenses to be matched with related revenue is called",
    options: [
      { label: "A", text: "going concern" },
      { label: "B", text: "matching concept" },
      { label: "C", text: "accrual concept" },
      { label: "D", text: "consistency concept" },
    ],
    correctAnswer: "B",
    explanation: "The matching concept requires that expenses incurred in earning revenue should be matched against that revenue in the same period.",
    difficulty: "medium",
    year: 2024,
  },

  // Economics Questions (15 varied questions)
  {
    id: "eco_001",
    subjectId: "economics",
    questionText: "The law of demand states that as price increases, quantity demanded",
    options: [
      { label: "A", text: "increases" },
      { label: "B", text: "decreases" },
      { label: "C", text: "remains constant" },
      { label: "D", text: "becomes zero" },
    ],
    correctAnswer: "B",
    explanation: "The law of demand shows an inverse relationship between price and quantity demanded, ceteris paribus.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "eco_002",
    subjectId: "economics",
    questionText: "Which factor will cause a rightward shift in the supply curve?",
    options: [
      { label: "A", text: "Increase in production costs" },
      { label: "B", text: "Improvement in technology" },
      { label: "C", text: "Increase in taxes" },
      { label: "D", text: "Decrease in number of sellers" },
    ],
    correctAnswer: "B",
    explanation: "Improvement in technology reduces production costs and increases supply, shifting the supply curve rightward.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eco_003",
    subjectId: "economics",
    questionText: "Opportunity cost refers to",
    options: [
      { label: "A", text: "the cost of the most expensive alternative" },
      { label: "B", text: "the cost of all alternatives foregone" },
      { label: "C", text: "the cost of the next best alternative foregone" },
      { label: "D", text: "the monetary cost of production" },
    ],
    correctAnswer: "C",
    explanation: "Opportunity cost is the value of the next best alternative that must be given up when making a choice.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eco_004",
    subjectId: "economics",
    questionText: "In perfect competition, firms are",
    options: [
      { label: "A", text: "price makers" },
      { label: "B", text: "price takers" },
      { label: "C", text: "price controllers" },
      { label: "D", text: "price discriminators" },
    ],
    correctAnswer: "B",
    explanation: "In perfect competition, individual firms have no control over market price and must accept the prevailing market price.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "eco_005",
    subjectId: "economics",
    questionText: "GDP at factor cost + indirect taxes - subsidies =",
    options: [
      { label: "A", text: "GNP at market prices" },
      { label: "B", text: "GDP at market prices" },
      { label: "C", text: "National income" },
      { label: "D", text: "Personal income" },
    ],
    correctAnswer: "B",
    explanation: "GDP at market prices equals GDP at factor cost plus indirect taxes minus subsidies.",
    difficulty: "hard",
    year: 2024,
  },

  // Yoruba Questions (15 varied questions)
  {
    id: "yor_001",
    subjectId: "yoruba",
    questionText: "Kí ni ìtumọ̀ òrọ̀ 'àgbà' ní èdè Yorùbá?",
    options: [
      { label: "A", text: "Ọmọ kékeré" },
      { label: "B", text: "Eniyan àgbà" },
      { label: "C", text: "Obìnrin" },
      { label: "D", text: "Ọkùnrin" },
    ],
    correctAnswer: "B",
    explanation: "'Àgbà' túmọ̀ sí eniyan tí ó ti dàgbà ní ọjọ́ orí tàbí tí ó ní ìrírí púpọ̀.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "yor_002",
    subjectId: "yoruba",
    questionText: "Èwo nínú àwọn wọ̀nyí ni àpẹẹrẹ àló?",
    options: [
      { label: "A", text: "Ó gún igi lọ sókè" },
      { label: "B", text: "Ọmọ ẹyẹ ń fò" },
      { label: "C", text: "Kí la ó ṣe àì ní epo, àì ní iyọ̀?" },
      { label: "D", text: "Oòrùn wá jáde" },
    ],
    correctAnswer: "C",
    explanation: "Àló jẹ́ àwọn ọ̀rọ̀ àfojúṣọ́ra tí ó ní ìtumọ̀ ìkọ́kọ́. 'Kí la ó ṣe àì ní epo, àì ní iyọ̀?' túmọ̀ sí pé kò sí nǹkan tí a lè ṣe.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "yor_003",
    subjectId: "yoruba",
    questionText: "Àwọn ìgbà ọdún mẹ́rin ni àwọn wo?",
    options: [
      { label: "A", text: "Ẹ̀rùn, òjò, ìgbóná, òtútù" },
      { label: "B", text: "Jánúárì, Fẹbruárì, Mọọ́si, Ẹprílì" },
      { label: "C", text: "Àárọ̀, ọ̀sán, àálẹ́, àṣálẹ́" },
      { label: "D", text: "Ọjọ́ Àìkú, Ọjọ́ Ajé, Ọjọ́ Ìṣẹ́gun, Ọjọ́ Ọ̀rún" },
    ],
    correctAnswer: "A",
    explanation: "Àwọn àkókò ọdún mẹ́rin ni ẹ̀rùn (harmattan), òjò (rainy season), ìgbóná (hot season), àti òtútù (cold season).",
    difficulty: "medium",
    year: 2024,
  },

  // Further Mathematics Questions (15 varied questions)
  {
    id: "fmt_001",
    subjectId: "further-mathematics",
    questionText: "If z = 3 + 4i, find |z|",
    options: [
      { label: "A", text: "5" },
      { label: "B", text: "7" },
      { label: "C", text: "12" },
      { label: "D", text: "25" },
    ],
    correctAnswer: "A",
    explanation: "For a complex number z = a + bi, |z| = √(a² + b²). So |3 + 4i| = √(3² + 4²) = √(9 + 16) = √25 = 5.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "fmt_002",
    subjectId: "further-mathematics",
    questionText: "Find the derivative of y = x³ + 2x² - 5x + 1",
    options: [
      { label: "A", text: "3x² + 4x - 5" },
      { label: "B", text: "x² + x - 5" },
      { label: "C", text: "3x² + 2x - 5" },
      { label: "D", text: "3x² + 4x - 1" },
    ],
    correctAnswer: "A",
    explanation: "Using the power rule: dy/dx = 3x² + 2(2x) - 5 + 0 = 3x² + 4x - 5.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "fmt_003",
    subjectId: "further-mathematics",
    questionText: "The vectors a = (2, 3) and b = (1, -2). Find a · b",
    options: [
      { label: "A", text: "-4" },
      { label: "B", text: "4" },
      { label: "C", text: "-2" },
      { label: "D", text: "8" },
    ],
    correctAnswer: "A",
    explanation: "Dot product a · b = (2)(1) + (3)(-2) = 2 - 6 = -4.",
    difficulty: "medium",
    year: 2024,
  },

  // Agricultural Science Questions (15 varied questions)
  {
    id: "agr_001",
    subjectId: "agricultural-science",
    questionText: "Which soil type is most suitable for rice cultivation?",
    options: [
      { label: "A", text: "Sandy soil" },
      { label: "B", text: "Clay soil" },
      { label: "C", text: "Loamy soil" },
      { label: "D", text: "Peaty soil" },
    ],
    correctAnswer: "B",
    explanation: "Clay soil retains water well and is ideal for rice cultivation which requires flooded conditions.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "agr_002",
    subjectId: "agricultural-science",
    questionText: "NPK fertilizer contains which three essential plant nutrients?",
    options: [
      { label: "A", text: "Nitrogen, Phosphorus, Potassium" },
      { label: "B", text: "Nitrogen, Phosphorus, Calcium" },
      { label: "C", text: "Nitrogen, Potassium, Sulphur" },
      { label: "D", text: "Phosphorus, Potassium, Magnesium" },
    ],
    correctAnswer: "A",
    explanation: "NPK stands for Nitrogen (N), Phosphorus (P), and Potassium (K) - the three primary macronutrients plants need.",
    difficulty: "easy",
    year: 2024,
  },
  {
    id: "agr_003",
    subjectId: "agricultural-science",
    questionText: "Which farming system involves growing crops and rearing animals on the same farm?",
    options: [
      { label: "A", text: "Monoculture" },
      { label: "B", text: "Mixed farming" },
      { label: "C", text: "Crop rotation" },
      { label: "D", text: "Intensive farming" },
    ],
    correctAnswer: "B",
    explanation: "Mixed farming combines crop production and livestock rearing on the same farm, providing multiple income sources.",
    difficulty: "medium",
    year: 2024,
  },
  {
    id: "agr_004",
    subjectId: "agricultural-science",
    questionText: "The process of preserving green fodder crops by fermentation is called",
    options: [
      { label: "A", text: "Silage" },
      { label: "B", text: "Hay making" },
      { label: "C", text: "Grazing" },
      { label: "D", text: "Straw treatment" },
    ],
    correctAnswer: "A",
    explanation: "Silage is produced by fermenting green fodder crops in anaerobic conditions to preserve them for animal feed.",
    difficulty: "hard",
    year: 2024,
  },
  {
    id: "agr_005",
    subjectId: "agricultural-science",
    questionText: "Which disease affects cocoa plants and causes black pod rot?",
    options: [
      { label: "A", text: "Phytophthora palmivora" },
      { label: "B", text: "Fusarium wilt" },
      { label: "C", text: "Bacterial blight" },
      { label: "D", text: "Mosaic virus" },
    ],
    correctAnswer: "A",
    explanation: "Phytophthora palmivora is the fungal pathogen responsible for black pod disease in cocoa, causing significant crop losses.",
    difficulty: "hard",
    year: 2024,
  },

  // Additional tough questions for existing subjects

  // More English Questions (Advanced Level)
  {
    id: "eng_009",
    subjectId: "use-of-english",
    questionText: "Choose the option that best explains the idiom: 'To beat around the bush'",
    options: [
      { label: "A", text: "To hit something repeatedly" },
      { label: "B", text: "To avoid speaking directly about a topic" },
      { label: "C", text: "To work in the garden" },
      { label: "D", text: "To make a lot of noise" },
    ],
    correctAnswer: "B",
    explanation: "To beat around the bush means to avoid talking about something directly or to speak evasively about a matter.",
    difficulty: "hard",
    year: 2024,
  },
  {
    id: "eng_010",
    subjectId: "use-of-english",
    questionText: "Identify the literary device in: 'The wind whispered through the trees'",
    options: [
      { label: "A", text: "Metaphor" },
      { label: "B", text: "Personification" },
      { label: "C", text: "Simile" },
      { label: "D", text: "Alliteration" },
    ],
    correctAnswer: "B",
    explanation: "Personification gives human qualities (whispering) to non-human things (wind), making the wind seem alive.",
    difficulty: "medium",
    year: 2024,
  },

  // More Mathematics Questions (Advanced Level)
  {
    id: "mth_006",
    subjectId: "mathematics",
    questionText: "If sin θ = 3/5 and θ is acute, find cos θ",
    options: [
      { label: "A", text: "4/5" },
      { label: "B", text: "3/4" },
      { label: "C", text: "5/4" },
      { label: "D", text: "5/3" },
    ],
    correctAnswer: "A",
    explanation: "Using Pythagorean identity: sin²θ + cos²θ = 1. If sin θ = 3/5, then cos²θ = 1 - (3/5)² = 1 - 9/25 = 16/25, so cos θ = 4/5.",
    difficulty: "hard",
    year: 2024,
  },
  {
    id: "mth_007",
    subjectId: "mathematics",
    questionText: "Find the sum of the first 10 terms of the arithmetic sequence: 2, 7, 12, 17, ...",
    options: [
      { label: "A", text: "245" },
      { label: "B", text: "250" },
      { label: "C", text: "255" },
      { label: "D", text: "260" },
    ],
    correctAnswer: "A",
    explanation: "First term a = 2, common difference d = 5. Using Sn = n/2[2a + (n-1)d]: S10 = 10/2[2(2) + 9(5)] = 5[4 + 45] = 5(49) = 245.",
    difficulty: "hard",
    year: 2024,
  },

  // More Physics Questions (Advanced Level)
  {
    id: "phy_006",
    subjectId: "physics",
    questionText: "A 2kg mass moving at 10m/s collides with a stationary 3kg mass. If they stick together, find their final velocity.",
    options: [
      { label: "A", text: "4 m/s" },
      { label: "B", text: "5 m/s" },
      { label: "C", text: "6 m/s" },
      { label: "D", text: "8 m/s" },
    ],
    correctAnswer: "A",
    explanation: "Using conservation of momentum: m₁v₁ + m₂v₂ = (m₁ + m₂)v. So 2(10) + 3(0) = (2+3)v, giving v = 20/5 = 4 m/s.",
    difficulty: "hard",
    year: 2024,
  },

  // More Chemistry Questions (Advanced Level)
  {
    id: "chm_006",
    subjectId: "chemistry",
    questionText: "What is the oxidation number of chromium in K₂Cr₂O₇?",
    options: [
      { label: "A", text: "+3" },
      { label: "B", text: "+6" },
      { label: "C", text: "+7" },
      { label: "D", text: "+12" },
    ],
    correctAnswer: "B",
    explanation: "In K₂Cr₂O₇: K has +1, O has -2. Let Cr be x. So 2(+1) + 2(x) + 7(-2) = 0, giving 2 + 2x - 14 = 0, so x = +6.",
    difficulty: "hard",
    year: 2024,
  },

  // More Biology Questions (Advanced Level)
  {
    id: "bio_006",
    subjectId: "biology",
    questionText: "Which hormone regulates blood glucose levels by promoting glucose uptake by cells?",
    options: [
      { label: "A", text: "Glucagon" },
      { label: "B", text: "Insulin" },
      { label: "C", text: "Adrenaline" },
      { label: "D", text: "Cortisol" },
    ],
    correctAnswer: "B",
    explanation: "Insulin is produced by beta cells in the pancreas and promotes glucose uptake by cells, lowering blood glucose levels.",
    difficulty: "medium",
    year: 2024,
  },
];

// Generate more questions for practice mode (100 per subject)
export function getQuestionsBySubject(subjectId: string): Question[] {
  const baseQuestions = SAMPLE_QUESTIONS.filter(q => q.subjectId === subjectId);
  
  // For demo purposes, we'll repeat and modify the sample questions
  // In a real app, you'd fetch from your database
  const questions: Question[] = [];
  
  for (let i = 0; i < 100; i++) {
    const baseQuestion = baseQuestions[i % baseQuestions.length];
    if (baseQuestion) {
      questions.push({
        ...baseQuestion,
        id: `${baseQuestion.subjectId}_${String(i + 1).padStart(3, '0')}`,
        questionText: baseQuestion.questionText,
      });
    }
  }
  
  return questions;
}

// Shuffle function to randomize array
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function getExamQuestions(subjects: string[]): Question[] {
  const questions: Question[] = [];
  
  subjects.forEach(subjectId => {
    const subjectQuestions = getQuestionsBySubject(subjectId);
    // Shuffle questions WITHIN each subject, then take required number
    const shuffledQuestions = shuffleArray(subjectQuestions);
    const questionCount = subjectId === 'use-of-english' ? 60 : 45; // English: 60, others: 45 each
    const examQuestions = shuffledQuestions.slice(0, questionCount);
    questions.push(...examQuestions);
  });
  
  // Return questions grouped by subject (don't mix subjects together)
  return questions; // Total: 180 questions
}
