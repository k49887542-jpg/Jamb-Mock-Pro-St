export interface Subject {
  id: string;
  name: string;
  code: string;
  description: string;
  icon: string;
  questionCount: number;
  isCore?: boolean;
}

export const JAMB_SUBJECTS: Subject[] = [
  {
    id: "use-of-english",
    name: "Use of English",
    code: "ENG",
    description: "Compulsory for all candidates",
    icon: "language",
    questionCount: 60,
    isCore: true,
  },
  {
    id: "mathematics",
    name: "Mathematics",
    code: "MTH",
    description: "Essential for most science and commercial courses",
    icon: "calculator",
    questionCount: 40,
  },
  {
    id: "physics",
    name: "Physics",
    code: "PHY",
    description: "Required for engineering and science courses",
    icon: "atom",
    questionCount: 40,
  },
  {
    id: "chemistry",
    name: "Chemistry",
    code: "CHM",
    description: "Essential for medical and science courses",
    icon: "flask",
    questionCount: 40,
  },
  {
    id: "biology",
    name: "Biology",
    code: "BIO",
    description: "Required for medical and life science courses",
    icon: "leaf",
    questionCount: 40,
  },
  {
    id: "government",
    name: "Government",
    code: "GOV",
    description: "Essential for law and social science courses",
    icon: "university",
    questionCount: 40,
  },
  {
    id: "economics",
    name: "Economics",
    code: "ECO",
    description: "Required for business and social science courses",
    icon: "trending-up",
    questionCount: 40,
  },
  {
    id: "literature-english",
    name: "Literature in English",
    code: "LIT",
    description: "Required for arts and language courses",
    icon: "book",
    questionCount: 40,
  },
  {
    id: "geography",
    name: "Geography",
    code: "GEO",
    description: "Essential for environmental and earth sciences",
    icon: "globe",
    questionCount: 40,
  },
  {
    id: "history",
    name: "History",
    code: "HIS",
    description: "Required for arts and social science courses",
    icon: "scroll",
    questionCount: 40,
  },
  {
    id: "accounting",
    name: "Accounting",
    code: "ACC",
    description: "Essential for business and commercial courses",
    icon: "calculator",
    questionCount: 40,
  },
  {
    id: "yoruba",
    name: "Yoruba",
    code: "YOR",
    description: "Nigerian language for arts and cultural studies",
    icon: "languages",
    questionCount: 40,
  },
  {
    id: "further-mathematics",
    name: "Further Mathematics",
    code: "FMT",
    description: "Advanced mathematics for engineering and science",
    icon: "sigma",
    questionCount: 40,
  },
  {
    id: "agricultural-science",
    name: "Agricultural Science",
    code: "AGR",
    description: "Essential for agriculture and food science courses",
    icon: "wheat",
    questionCount: 40,
  },
];

export const POPULAR_COMBINATIONS = [
  {
    course: "Medicine & Surgery",
    subjects: ["use-of-english", "biology", "physics", "chemistry"],
  },
  {
    course: "Engineering",
    subjects: ["use-of-english", "mathematics", "physics", "chemistry"],
  },
  {
    course: "Computer Science",
    subjects: ["use-of-english", "mathematics", "physics", "chemistry"],
  },
  {
    course: "Law",
    subjects: ["use-of-english", "literature-english", "government", "history"],
  },
  {
    course: "Accounting",
    subjects: ["use-of-english", "mathematics", "economics", "accounting"],
  },
  {
    course: "Biochemistry",
    subjects: ["use-of-english", "biology", "physics", "chemistry"],
  },
  {
    course: "Agriculture",
    subjects: ["use-of-english", "agricultural-science", "chemistry", "biology"],
  },
  {
    course: "Yoruba Studies",
    subjects: ["use-of-english", "yoruba", "history", "literature-english"],
  },
  {
    course: "Mathematical Sciences",
    subjects: ["use-of-english", "mathematics", "further-mathematics", "physics"],
  },
];
