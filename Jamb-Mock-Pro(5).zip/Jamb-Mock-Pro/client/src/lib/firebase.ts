import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyCSVbZVsBO8luLUT-HznUQe57FGRZ_2U5g",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "jambgenius.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "jambgenius",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "jambgenius.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "1057264829205",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:1057264829205:web:bde437c1236c7242d95f1c"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;
