import { 
  type User, 
  type InsertUser, 
  type Subject, 
  type InsertSubject,
  type Question,
  type InsertQuestion,
  type PracticeAttempt,
  type InsertPracticeAttempt,
  type ExamAttempt,
  type InsertExamAttempt,
  type UserProgress,
  type InsertUserProgress
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Subject methods
  getAllSubjects(): Promise<Subject[]>;
  getSubject(id: string): Promise<Subject | undefined>;
  createSubject(subject: InsertSubject): Promise<Subject>;
  
  // Question methods
  getQuestionsBySubject(subjectId: string, limit?: number): Promise<Question[]>;
  getQuestion(id: string): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  
  // Practice attempt methods
  createPracticeAttempt(attempt: InsertPracticeAttempt): Promise<PracticeAttempt>;
  getPracticeAttemptsByUser(userId: string): Promise<PracticeAttempt[]>;
  
  // Exam attempt methods
  createExamAttempt(attempt: InsertExamAttempt): Promise<ExamAttempt>;
  getExamAttemptsByUser(userId: string): Promise<ExamAttempt[]>;
  updateExamAttempt(id: string, attempt: Partial<ExamAttempt>): Promise<ExamAttempt | undefined>;
  
  // User progress methods
  getUserProgress(userId: string, subjectId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, subjectId: string, progress: InsertUserProgress): Promise<UserProgress>;
  getAllUserProgress(userId: string): Promise<UserProgress[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private subjects: Map<string, Subject>;
  private questions: Map<string, Question>;
  private practiceAttempts: Map<string, PracticeAttempt>;
  private examAttempts: Map<string, ExamAttempt>;
  private userProgress: Map<string, UserProgress>;

  constructor() {
    this.users = new Map();
    this.subjects = new Map();
    this.questions = new Map();
    this.practiceAttempts = new Map();
    this.examAttempts = new Map();
    this.userProgress = new Map();
    
    // Initialize with default subjects and questions
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default subjects
    const defaultSubjects = [
      {
        id: "use-of-english",
        name: "Use of English",
        code: "ENG",
        description: "Compulsory for all candidates",
        icon: "language",
        questionCount: 60,
      },
      {
        id: "mathematics",
        name: "Mathematics",
        code: "MTH",
        description: "Essential for most science and commercial courses",
        icon: "calculator",
        questionCount: 40,
      },
      {
        id: "physics",
        name: "Physics",
        code: "PHY",
        description: "Required for engineering and science courses",
        icon: "atom",
        questionCount: 40,
      },
      {
        id: "chemistry",
        name: "Chemistry",
        code: "CHM",
        description: "Essential for medical and science courses",
        icon: "flask",
        questionCount: 40,
      },
    ];

    defaultSubjects.forEach(subject => {
      this.subjects.set(subject.id, subject as Subject);
    });

    // Create sample questions
    const sampleQuestions = [
      {
        id: "eng_001",
        subjectId: "use-of-english",
        questionText: "Choose the option with the correct stress pattern. The stressed syllables are written in capital letters.",
        options: [
          { label: "A", text: "phoTOgraphy" },
          { label: "B", text: "PHOtography" },
          { label: "C", text: "photoGRAphy" },
          { label: "D", text: "photograPHY" },
        ],
        correctAnswer: "A",
        explanation: "The correct stress pattern for 'photography' is pho-TO-gra-phy, with stress on the second syllable.",
        difficulty: "medium" as const,
        year: 2024,
      },
      {
        id: "mth_001",
        subjectId: "mathematics",
        questionText: "If log₂ 8 = x, find the value of x.",
        options: [
          { label: "A", text: "2" },
          { label: "B", text: "3" },
          { label: "C", text: "4" },
          { label: "D", text: "8" },
        ],
        correctAnswer: "B",
        explanation: "log₂ 8 = x means 2ˣ = 8. Since 2³ = 8, therefore x = 3.",
        difficulty: "medium" as const,
        year: 2024,
      },
    ];

    sampleQuestions.forEach(question => {
      this.questions.set(question.id, question as Question);
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.firebaseUid === firebaseUid);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      id, 
      firebaseUid: insertUser.firebaseUid,
      email: insertUser.email,
      displayName: insertUser.displayName || null,
      photoURL: insertUser.photoURL || null,
      examCredits: insertUser.examCredits || 0,
      isPremium: insertUser.isPremium || false,
      premiumExpiresAt: insertUser.premiumExpiresAt || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Subject methods
  async getAllSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubject(id: string): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  async createSubject(insertSubject: InsertSubject): Promise<Subject> {
    const id = randomUUID();
    const subject: Subject = { 
      id, 
      name: insertSubject.name,
      code: insertSubject.code,
      description: insertSubject.description || null,
      icon: insertSubject.icon || null,
      questionCount: insertSubject.questionCount || null
    };
    this.subjects.set(id, subject);
    return subject;
  }

  // Question methods
  async getQuestionsBySubject(subjectId: string, limit?: number): Promise<Question[]> {
    const questions = Array.from(this.questions.values()).filter(q => q.subjectId === subjectId);
    return limit ? questions.slice(0, limit) : questions;
  }

  async getQuestion(id: string): Promise<Question | undefined> {
    return this.questions.get(id);
  }

  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const id = randomUUID();
    const question: Question = { 
      id, 
      subjectId: insertQuestion.subjectId,
      questionText: insertQuestion.questionText,
      options: insertQuestion.options,
      correctAnswer: insertQuestion.correctAnswer,
      explanation: insertQuestion.explanation || null,
      difficulty: insertQuestion.difficulty || null,
      year: insertQuestion.year || null
    };
    this.questions.set(id, question);
    return question;
  }

  // Practice attempt methods
  async createPracticeAttempt(insertAttempt: InsertPracticeAttempt): Promise<PracticeAttempt> {
    const id = randomUUID();
    const attempt: PracticeAttempt = { 
      id, 
      userId: insertAttempt.userId,
      subjectId: insertAttempt.subjectId,
      questionId: insertAttempt.questionId,
      selectedAnswer: insertAttempt.selectedAnswer || null,
      isCorrect: insertAttempt.isCorrect || null,
      timeSpent: insertAttempt.timeSpent || null,
      createdAt: new Date() 
    };
    this.practiceAttempts.set(id, attempt);
    return attempt;
  }

  async getPracticeAttemptsByUser(userId: string): Promise<PracticeAttempt[]> {
    return Array.from(this.practiceAttempts.values()).filter(attempt => attempt.userId === userId);
  }

  // Exam attempt methods
  async createExamAttempt(insertAttempt: InsertExamAttempt): Promise<ExamAttempt> {
    const id = randomUUID();
    const attempt: ExamAttempt = { 
      id, 
      userId: insertAttempt.userId,
      totalQuestions: insertAttempt.totalQuestions || null,
      totalCorrect: insertAttempt.totalCorrect || null,
      totalScore: insertAttempt.totalScore || null,
      timeSpent: insertAttempt.timeSpent || null,
      subjects: insertAttempt.subjects,
      answers: insertAttempt.answers,
      startedAt: new Date(),
      completedAt: null
    };
    this.examAttempts.set(id, attempt);
    return attempt;
  }

  async getExamAttemptsByUser(userId: string): Promise<ExamAttempt[]> {
    return Array.from(this.examAttempts.values()).filter(attempt => attempt.userId === userId);
  }

  async updateExamAttempt(id: string, updates: Partial<ExamAttempt>): Promise<ExamAttempt | undefined> {
    const attempt = this.examAttempts.get(id);
    if (!attempt) return undefined;
    
    const updatedAttempt = { ...attempt, ...updates };
    this.examAttempts.set(id, updatedAttempt);
    return updatedAttempt;
  }

  // User progress methods
  async getUserProgress(userId: string, subjectId: string): Promise<UserProgress | undefined> {
    const key = `${userId}_${subjectId}`;
    return this.userProgress.get(key);
  }

  async updateUserProgress(userId: string, subjectId: string, insertProgress: InsertUserProgress): Promise<UserProgress> {
    const key = `${userId}_${subjectId}`;
    const id = randomUUID();
    const progress: UserProgress = { 
      id, 
      userId, 
      subjectId,
      totalAttempts: insertProgress.totalAttempts || null,
      correctAnswers: insertProgress.correctAnswers || null,
      averageScore: insertProgress.averageScore || null,
      lastAttemptAt: insertProgress.lastAttemptAt || null,
      updatedAt: new Date() 
    };
    this.userProgress.set(key, progress);
    return progress;
  }

  async getAllUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }
}

export const storage = new MemStorage();
