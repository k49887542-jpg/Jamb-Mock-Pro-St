# 📝 Complete Question Editing Guide

## Where Your Questions Are Located

Your questions are stored in: **`client/src/data/questions.ts`**

This file contains all practice and exam questions for your JAMB Mock Pro app.

## 🎯 How Questions Work in Your App

### Practice Mode:
- Shows **all questions** with detailed explanations
- Students can see answers immediately  
- Includes difficulty levels and year tags
- Perfect for learning and understanding

### Exam Mode:
- Randomly selects **180 questions total**:
  - 60 Use of English questions
  - 40 Mathematics questions  
  - 40 Physics questions
  - 40 Chemistry questions
  - (Biology optional based on student selection)
- **Timed 2-hour exam** (JAMB standard)
- **No explanations** during exam (realistic simulation)
- Questions shuffled each time

## 📚 How to Add New Questions

### Step 1: Open the Questions File
Edit: `client/src/data/questions.ts`

### Step 2: Copy This Template
```typescript
{
  id: "eng_050", // Make this unique (eng_050, math_100, etc.)
  subjectId: "use-of-english", // Subject category
  questionText: "Your question text goes here?",
  options: [
    { label: "A", text: "First option" },
    { label: "B", text: "Second option" },
    { label: "C", text: "Third option" },
    { label: "D", text: "Fourth option" },
  ],
  correctAnswer: "A", // Which option is correct (A, B, C, or D)
  explanation: "Detailed explanation of why this answer is correct. Include teaching points and clarification.",
  difficulty: "medium", // easy, medium, or hard
  year: 2024, // JAMB year (optional)
},
```

### Step 3: Subject Categories
Use these exact subject IDs:
- `"use-of-english"` - English Language
- `"mathematics"` - Mathematics  
- `"physics"` - Physics
- `"chemistry"` - Chemistry
- `"biology"` - Biology

### Step 4: Question ID Patterns
Create unique IDs using this pattern:
- English: `eng_001`, `eng_002`, `eng_003`...
- Math: `math_001`, `math_002`, `math_003`...
- Physics: `phy_001`, `phy_002`, `phy_003`...
- Chemistry: `chem_001`, `chem_002`, `chem_003`...
- Biology: `bio_001`, `bio_002`, `bio_003`...

## ✏️ Editing Existing Questions

### Find and Replace:
1. **Search for the question ID** you want to edit
2. **Update any field** (question text, options, answer, explanation)
3. **Keep the same ID** to maintain consistency
4. **Save the file**

### Example Edit:
```typescript
// BEFORE:
{
  id: "eng_001",
  questionText: "Old question text?",
  correctAnswer: "A",
  explanation: "Old explanation",
}

// AFTER:
{
  id: "eng_001", // Keep same ID
  questionText: "Updated question text?", // Changed
  correctAnswer: "B", // Changed if needed
  explanation: "Updated detailed explanation", // Changed
}
```

## 🎯 Question Writing Best Practices

### Good Question Format:
```typescript
{
  id: "eng_051",
  subjectId: "use-of-english",
  questionText: "Choose the option that best completes the sentence: The student _____ his homework before going to bed.",
  options: [
    { label: "A", text: "completed" },
    { label: "B", text: "complete" },
    { label: "C", text: "completing" },
    { label: "D", text: "completes" },
  ],
  correctAnswer: "A",
  explanation: "The past tense 'completed' is correct because the action happened before another past action ('going to bed'). This demonstrates the past perfect tense usage.",
  difficulty: "medium",
  year: 2024,
}
```

### Writing Tips:
- **Clear Questions**: Make sure the question is unambiguous
- **Balanced Options**: All options should seem plausible
- **Good Explanations**: Teach the concept, don't just state the answer
- **Appropriate Difficulty**: Match JAMB standard difficulty levels

## 📊 Current Question Count

Your app currently has sample questions. You can:
- **Add unlimited questions** - no technical limit
- **Mix difficulty levels** - easy, medium, hard
- **Include recent JAMB patterns** - keep content current
- **Add explanations for all** - helps students learn

## 🔄 How Updates Work

### After Adding Questions:
1. **Save the file** (`client/src/data/questions.ts`)
2. **Upload to GitHub** (your changes)
3. **APK rebuilds automatically** (5-10 minutes)
4. **New questions appear** in the app immediately

### No Database Needed:
- Questions are stored in the code file
- No complex database setup required
- Easy to backup and version control
- Questions work offline in the mobile app

## 📱 Question Features in Your App

### For Students:
- **Search by subject** - find specific topics
- **Difficulty filtering** - choose appropriate level
- **Progress tracking** - see improvement over time
- **Offline access** - practice without internet
- **Detailed explanations** - learn from mistakes

### For Exam Mode:
- **Realistic simulation** - matches JAMB format
- **Timed sessions** - 2-hour limit
- **Random selection** - different questions each time
- **Score calculation** - out of 400 marks total
- **Performance analytics** - detailed results

## 🎯 Subject-Specific Question Examples

### Use of English Sample:
```typescript
{
  id: "eng_052",
  subjectId: "use-of-english",
  questionText: "Choose the option with the correct stress pattern: 'photograph'",
  options: [
    { label: "A", text: "PHOtograph" },
    { label: "B", text: "photoGRAPH" },
    { label: "C", text: "PHOTOgraph" },
    { label: "D", text: "photograPH" },
  ],
  correctAnswer: "A",
  explanation: "The word 'photograph' has primary stress on the first syllable: PHO-to-graph.",
  difficulty: "medium",
  year: 2024,
}
```

### Mathematics Sample:
```typescript
{
  id: "math_051",
  subjectId: "mathematics",
  questionText: "Solve for x in the equation: 2x + 5 = 13",
  options: [
    { label: "A", text: "x = 3" },
    { label: "B", text: "x = 4" },
    { label: "C", text: "x = 6" },
    { label: "D", text: "x = 8" },
  ],
  correctAnswer: "B",
  explanation: "2x + 5 = 13. Subtract 5 from both sides: 2x = 8. Divide by 2: x = 4.",
  difficulty: "easy",
  year: 2024,
}
```

## 🚀 Quick Start: Adding Your First Question

1. **Open** `client/src/data/questions.ts`
2. **Find the end** of the SAMPLE_QUESTIONS array (look for the last `},`)
3. **Add a comma** after the last question
4. **Paste your new question** using the template above
5. **Update the ID, text, and answers**
6. **Save the file**
7. **Test locally** with `npm run dev`
8. **Upload to GitHub** for APK rebuild

Your JAMB Mock Pro can now grow with unlimited questions and your students will always have fresh content to practice with!