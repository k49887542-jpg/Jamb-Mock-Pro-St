# GitHub Actions APK Build Setup

## Automatic APK Building with GitHub Actions

This will create an APK automatically every time you update your code:

### 1. GitHub Workflow File

Create `.github/workflows/build-android.yml`:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v4
      
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
        
    - name: Setup JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Setup Android SDK
      uses: android-actions/setup-android@v3
      
    - name: Install dependencies
      run: npm install
      
    - name: Build web app
      run: npm run build
      
    - name: Sync Capacitor
      run: npx cap sync android
      
    - name: Build APK
      run: |
        cd android
        ./gradlew assembleDebug
        
    - name: Upload APK
      uses: actions/upload-artifact@v4
      with:
        name: jamb-mock-pro-debug
        path: android/app/build/outputs/apk/debug/app-debug.apk
        
    - name: Create Release
      if: github.ref == 'refs/heads/main'
      uses: actions/create-release@v1
      env:
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      with:
        tag_name: v1.0.${{ github.run_number }}
        release_name: JAMB Mock Pro v1.0.${{ github.run_number }}
        body: |
          Automated build of JAMB Mock Pro Android APK
          
          **Download the APK file below to install on Android devices**
        draft: false
        prerelease: false
        
    - name: Upload Release Asset
      if: github.ref == 'refs/heads/main'
      uses: actions/upload-release-asset@v1
      env:
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      with:
        upload_url: ${{ steps.create_release.outputs.upload_url }}
        asset_path: android/app/build/outputs/apk/debug/app-debug.apk
        asset_name: jamb-mock-pro.apk
        asset_content_type: application/vnd.android.package-archive
```

### 2. How It Works

1. **Push to GitHub**: Every time you update your code
2. **Automatic Build**: GitHub builds the APK in the cloud
3. **Download Ready**: APK available in GitHub releases
4. **Version Tracking**: Each build gets a version number

### 3. Benefits

- ✅ **Free**: GitHub provides 2000 minutes/month for free
- ✅ **Automatic**: No manual building required
- ✅ **Professional**: Industry-standard CI/CD workflow
- ✅ **Version Control**: Every build is tracked and downloadable
- ✅ **Shareable**: Direct download links for testing

### 4. Setup Instructions

1. **Push to GitHub**: Upload your project to a GitHub repository
2. **Add Workflow**: Create the `.github/workflows/build-android.yml` file
3. **Push Changes**: The workflow runs automatically
4. **Download APK**: Get it from the "Releases" section

### 5. Release APK Setup

For Google Play Store distribution, I'll also set up:

```yaml
# Additional job for release builds
release-build:
  if: startsWith(github.ref, 'refs/tags/')
  runs-on: ubuntu-latest
  steps:
    # ... same setup steps ...
    - name: Build Release APK
      run: |
        cd android
        ./gradlew assembleRelease
```

This ensures you get both debug APKs for testing and release APKs for the Play Store.

Would you like me to create this GitHub Actions workflow for your project?