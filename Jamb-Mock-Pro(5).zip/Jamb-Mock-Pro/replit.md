# JAMB Mock Pro - Nigeria's Premier JAMB UTME Preparation Platform

## Overview

JAMB Mock Pro is a comprehensive JAMB UTME preparation platform built as a full-stack web application. The application provides Nigerian students with practice questions, mock examinations, and performance analytics to help them prepare for the Joint Admissions and Matriculation Board (JAMB) Unified Tertiary Matriculation Examination (UTME).

The platform offers two primary study modes: a free Practice Mode with detailed explanations and immediate feedback, and a timed Mock Exam Mode that simulates the actual JAMB examination experience. Students can track their progress across multiple subjects including Use of English, Mathematics, Physics, Chemistry, and Biology.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (August 2025)

**Mobile App Conversion (August 9, 2025):**
- Successfully converted PWA to native Android app using Capacitor
- Created complete Android project structure with package ID: `com.jambmockpro.app`
- Configured app icons, splash screens, and Android manifest for Play Store readiness
- Set up Capacitor configuration with proper branding and native features
- Prepared build system for APK generation via GitHub Actions or local Android Studio
- App is now ready for Google Play Store distribution after APK compilation

## Previous Changes (January 2025)

**Security and Authentication Improvements:**
- Fixed Google OAuth authentication to use popup instead of redirect for better user experience
- Implemented comprehensive server-side authentication middleware using Firebase Admin SDK
- Added secure payment verification system with credit deduction and server-side validation
- Updated all components to use secure useUser hook instead of deprecated useAuth
- Fixed authentication persistence and payment bypass vulnerabilities
- **Added hCaptcha verification** to prevent bot registrations and fraudulent payments
- Integrated hCaptcha protection on signup forms and payment processing flows
- Created reusable HCaptchaWrapper component with error handling and analytics tracking

**JAMB Examination Standards:**
- Corrected exam duration from 3 hours to 2 hours (JAMB standard)
- Fixed scoring system to show results out of 400 marks total instead of 195
- Ensured exactly 180 questions total: 60 English, 40 Math, 40 Physics, 40 Chemistry
- Improved question shuffling to shuffle within subjects only, not mixing subjects together

**User Experience Enhancements:**
- Added email verification for new user registrations
- Implemented back navigation buttons on all exam pages
- Fixed Google sign-in authentication flow with proper error handling
- Added comprehensive navigation between exam questions with status indicators

## System Architecture

### Frontend Architecture
The client-side is built using React with TypeScript, utilizing Vite as the build tool and development server. The architecture follows a component-based design pattern with:

- **UI Framework**: Radix UI components with shadcn/ui styling system for consistent, accessible user interfaces
- **Styling**: Tailwind CSS for utility-first styling with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **Authentication**: Firebase Authentication with Google OAuth integration
- **Component Structure**: Modular components organized by feature (auth, exam, practice, analytics)

### Backend Architecture
The server-side follows a RESTful API design pattern built with:

- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for type safety and better development experience
- **API Design**: REST endpoints for user management, subjects, questions, and attempt tracking
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development
- **Middleware**: Custom logging middleware for API request/response tracking

### Data Storage Solutions
The application uses a flexible storage architecture:

- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless database integration
- **Schema Management**: Centralized schema definitions in TypeScript with Zod validation
- **Data Models**: Users, subjects, questions, practice attempts, exam attempts, and user progress tracking

### Authentication and Authorization
Authentication is handled through Firebase Auth:

- **Provider**: Google OAuth for user sign-in
- **Session Management**: Firebase handles token management and user sessions
- **User Data**: Custom user profiles stored in PostgreSQL linked to Firebase UIDs
- **Authorization**: Client-side authentication state management with React hooks

### Design Patterns and Architectural Decisions

**Component Architecture**: The frontend uses a layered component structure separating UI components, page components, and business logic hooks. This promotes reusability and maintainability.

**Type Safety**: TypeScript is used throughout the stack with shared type definitions between client and server, ensuring data consistency and reducing runtime errors.

**Responsive Design**: Mobile-first responsive design using Tailwind CSS breakpoints to ensure usability across devices.

**State Management**: Server state is managed separately from client state using TanStack React Query, providing caching, background updates, and optimistic updates.

**Error Handling**: Comprehensive error boundaries and try-catch blocks with user-friendly error messages and proper HTTP status codes.

## External Dependencies

### Database and Backend Services
- **Neon Database**: Serverless PostgreSQL database for production data storage
- **Drizzle Kit**: Database migration and schema management tool

### Authentication Services
- **Firebase Authentication**: Handles user authentication and session management
- **Google OAuth**: Primary authentication provider for user sign-in

### Frontend Libraries and Frameworks
- **React**: Core UI framework with hooks for state management
- **Vite**: Build tool and development server with hot module replacement
- **Wouter**: Lightweight routing library for client-side navigation
- **TanStack React Query**: Server state management and data synchronization

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Radix UI**: Headless UI components for accessibility and functionality
- **shadcn/ui**: Pre-built component system based on Radix UI
- **Lucide React**: Icon library for consistent iconography

### Development and Build Tools
- **TypeScript**: Type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer
- **Replit Integration**: Development environment integration with runtime error handling

### Validation and Utilities
- **Zod**: Runtime type validation and schema parsing
- **date-fns**: Date manipulation and formatting utilities
- **clsx**: Conditional CSS class name utility
- **class-variance-authority**: Type-safe variant API for component styling